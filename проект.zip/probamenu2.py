import tkinter as Tk
from PIL import Image, ImageTk 
import numpy as np 
import matplotlib.pyplot as plt 
from scipy.integrate import odeint
import matplotlib.animation as animation
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
 
window = Tk.Tk()
window.title("Калькулятор Солнечной системы")  
window.geometry('400x250')  
 
mainmenu = Tk.Menu(window) 
window.config(menu=mainmenu) 

lbl1 = Tk.Label(window) 
lbl1.grid(column=0, row=1)  
lbl2 = Tk.Label(window) 
lbl2.grid(column=0, row=1)  
 
m_sun=1.98847*10**30
G=6.67*10**(-11)


def clicked():  
    windows = Toplevel()
    windows.title('Сила всемирного тяготения')
    img = ImageTk.PhotoImage(Image.open("nuton2.jpg"))
    panel = Label(windows, image=img)
    panel.pack()
    button = Button(windows, text='открыть окно', command= clicked)
    button.place(column=0, row=0)

def clicked2(): 
    root = Tk.Tk()
    root.title('Солнечная система')
    lbl1= Tk.Label(root, text='Планеты и Солнце')   
    lbl1.grid(column=0, row=0)
    button_sun = Tk.Button(root, text='Солнце', command=sun)
    button_sun.grid(column=0, row=1)
    text_sun= 'Солнце- звезда, находящаяся в центре солнечной системы.\n Сила всемирного тяготения удерживает около массивного центра\n 8 больших планет и множество малых тел Солнечной системы.\n Масса Солнца составляет 1.989e30 кг(умножить на 10 в степени 30), радиус 696 340 км. \n Возраст Солнца около 5 млрд. лет, а Солнечной системы - около 4.5 млрд. лет.\n В близкой к Солнцу области, откуда давлением света удалило большую часть газа,\n образовались те планеты, в которых преобладали железо, кремний и углерод.\n Это планеты земной группы: Меркурий, Венера, Земля, Марс.\n При образовании более удалённых планет- гигантов: Юпитера, Сатурна, Урана и Нептуна,\n основным материалом были газы (водород и гелий).'
    lbl_sun= Tk.Label (root, text= text_sun, justify= LEFT )   
    lbl_sun.grid(column=0, row=2)
    button_merc = Tk.Button(root, text='Меркурий', command=merc)
    button_merc.grid(column=0, row=3)
    text_merc= 'Меркурий- самая близкая к Солнцу и самая маленькая планета.\n Расстояние от неё до Солнца чуть меньше 58 млн. км.\n Своё название Меркурий получил в честь бога торговли и посланника богов.\n Радиус Меркурия составляет 2439 км, а масса  3,3е23 кг.\n Ни воды, ни атмосферы на этой планете нет.\n Ночная температура доходит до -170°С, а в течении дня поверхность нагревается до 427°С.'
    lbl_merc= Tk.Label (root, text= text_merc, justify= LEFT )   
    lbl_merc.grid(column=0, row=4)
    button_ven = Tk.Button(root, text='Венера', command=ven)
    button_ven.grid(column=0, row=5)
    text_ven='Венера- планета, которая получила своё название в честь римской богини любви\n и красоты.\n От Солнца её отделяет 108 млн. км.\n Венера- самый яркий объект на небе после Солнца и Луны.\n Радиус Венеры 6051 км, а масса 4.87e24. Венера, как и Земля, имеет атмосферу.\n Она состоит из углекислого газа, ядовитого угарного газа, фтористого\n и хлористого водорода.\n Рельеф Венеры состоит из равнин, пересечённых горными цепями.\n Формы рельефа на планете получили интересные названия, например: 2 горные области-\n Земля Афродиты и Земля Иштар, долина Лакшми, кратер Клеопатра и кратер Баба-Яга.'
    lbl_ven= Tk.Label (root, text= text_ven, justify= LEFT )   
    lbl_ven.grid(column=0, row=6)
    button_earth = Tk.Button(root, text='Земля', command=earth)
    button_earth.grid(column=0, row=7)
    text_earth='Земля- наша родная планета, находится на расстоянии 150 млн. км от Солнца.\n Радиус земного шара 6371 км, масса 5.98•10²4 кг.\n Большое количество кислорода в воздухе (около 20%) сделало возможным появление\n жизни.\nЗемная атмосфера простирается на расстояние до 10 тыс. км и состоит из нескольких слоев:\n тропосферы, стратосферы, мезосферы, термосферы и экзосферы.\n Луну- спутник Земли- занимают обширные горные области.\n Она вращается вокруг оси с той же скоростью, что и по орбите, из-за этого с Земли видна\n только одна её сторона.'
    lbl_earth= Tk.Label (root, text= text_earth, justify= LEFT )   
    lbl_earth.grid(column=0, row=8)
    button_mars = Tk.Button(root, text='Марс', command=mars)
    button_mars.grid(column=0, row=9)
    text_mars= 'Марс- четвёртая планета Солнечной Системы находится на расстоянии 228 млн.км\n от Солнца. Планета получила своё название от бога войны римлян Марса за своё красное\n "кровавое" сияние. Рельеф поверхности довольно сложен: здесь множество кратеров,\n горных хребтов, плоских возвышенностей. Самая высокая точка планеты- Вулкан Олимп(27км).\n Марс в 2 раза легче Земли по массе и в два раза меньше в диаметре\n(радиус равен 3389.5 км, масса - 6.39e23).\n У Марса есть тонкая и разряженная атмосфера, образованная углекислым газом.'
    lbl_mars= Tk.Label (root, text= text_mars, justify= LEFT )   
    lbl_mars.grid(column=0, row=10)
    button_yup = Tk.Button(root, text='Юпитер', command=yup)
    button_yup.grid(column=2, row=1)
    text_yup='Юпитер- самая большая планета Солнечной системы. От Солнца её отделяет 778 млн. км.\n Юпитер- планета-гигант. Радиус составляет 71 400 км, а масса 1.9e27 кг.\n Эта газовая планета состоит из водорода, а её атмосфера включает кроме водорода\n ещё и гелий, метан, амиак и водяной пар.\n В атмосфере расположены слои облаков, из-за чего Юпитер кажется полосатым.\n Большое Красное пятно на Юпитере- это огромное атмосферное образование\n(которое вдвое превосходит размеры Земли).'
    lbl_yup= Tk.Label (root, text= text_yup, justify= LEFT )   
    lbl_yup.grid(column=2, row=2)
    button_saturn = Tk.Button(root, text='Сатурн', command=saturn)
    button_saturn.grid(column=2, row=3)
    text_saturn='Сатурн- планета, окружённая широкими светлыми кольцами. Он назван так в честь\n древнеримского божества плодородия Сатурна. \n Радиус планеты 60000 км, а масса 5.7e26 кг. Сатурн, как и Юпитер, состоит в основном\n из водорода.\n Кольца Сатурна образованы различными частицами, камнями различных размеров,\n покрытыми инеем и льдом.' 
    lbl_saturn= Tk.Label (root, text= text_saturn, justify= LEFT )   
    lbl_saturn.grid(column=2, row=4)
    button_uran = Tk.Button(root, text='Уран', command=uran)
    button_uran.grid(column=2, row=5)
    text_uran= 'Уран- седьмая планета Солнечной системы, рсположенная на расстоянии\n 2.87 млрд км от Солнца.\n Планета получила своё название по имени древнегреческого бога неба, супруга Геи-\n земли.\n Уран имеет радиус 25900 км и массу 8.7e25кг.\n Ось вращения планеты имеет наклон 98°.\n Уран катится по орбите, при этом он переворачивается назад, но по орбите\n продвигается вперёд.'
    lbl_uran= Tk.Label (root, text= text_uran, justify= LEFT )
    lbl_uran.grid(column=2, row=6)
    button_neptun = Tk.Button(root, text='Нептун', command=neptun)
    button_neptun.grid(column=2, row=7)
    text_neptun='Нептун- последняя планета Солнечной системы.\n Расстояние от неё до Солнца 4.5 млрд. км.\n Планета получила название в честь римского бога моря.\n Радиус Нептуна 24 300 км, а масса 1.03e26.\n На диске этой планеты можно увидеть пятна атмосферных вихрей.\n Одно из них, окружённое белыми облаками, было названо Большое Тёмное Пятно.\n У Нептуна, как у Юпитера и Урана, также есть кольца.\n Однако, они неполные, на одних участках присутствуют скопления частиц,\n а на других- ничего.\n Кольца Нептуна названы дугами (или арками).'
    lbl_neptun= Tk.Label (root, text= text_neptun, justify= LEFT )
    lbl_neptun.grid(column=2, row=8)
def sun():
    windows = Toplevel()
    windows.title('Солнце')
    img = ImageTk.PhotoImage(Image.open("sun.jpg"))
    panel = Label(windows, image=img)
    panel.pack()
    button = Button(windows, text='Солнце', command=sun)
    button.place(column=0, row=0)

def merc():
    windows = Toplevel()
    windows.title('Меркурий')
    img = ImageTk.PhotoImage(Image.open("merc.jpg"))
    panel = Label(windows, image=img)
    panel.pack()
    button = Button(windows, text='Меркурий', command=sun)
    button.place(column=0, row=0)
def ven():
    windows = Toplevel()
    windows.title('Венера')
    img = ImageTk.PhotoImage(Image.open("venera.jpg"))
    panel = Label(windows, image=img)
    panel.pack()
    button = Button(windows, text='Венера', command=sun)
    button.place(column=0, row=0)
def earth():
    windows = Toplevel()
    windows.title('Земля')
    img = ImageTk.PhotoImage(Image.open("earth.jpg"))
    panel = Label(windows, image=img)
    panel.pack()
    button = Button(windows, text='Земля', command=sun)
    button.place(column=0, row=0)
def mars():
    windows = Toplevel()
    windows.title('Марс')
    img = ImageTk.PhotoImage(Image.open("mars.jpg"))
    panel = Label(windows, image=img)
    panel.pack()
    button = Button(windows, text='Марс', command=sun)
    button.place(column=0, row=0)
def yup():
    windows = Toplevel()
    windows.title('Юпитер')
    img = ImageTk.PhotoImage(Image.open("yup.jpg"))
    panel = Label(windows, image=img)
    panel.pack()
    button = Button(windows, text='Юпитер', command=sun)
    button.place(column=0, row=0)
    
def saturn():
    windows = Toplevel()
    windows.title('Сатурн')
    img = ImageTk.PhotoImage(Image.open("saturn.jpg"))
    panel = Label(windows, image=img)
    panel.pack()
    button = Button(windows, text='Сатурн', command=sun)
    button.place(column=0, row=0)
    
def uran():
    windows = Toplevel()
    windows.title('Уран')
    img = ImageTk.PhotoImage(Image.open("uran.jpg"))
    panel = Label(windows, image=img)
    panel.pack()
    button = Button(windows, text='Уран', command=sun)
    button.place(column=0, row=0)
def neptun():
    windows = Toplevel()
    windows.title('Нептун')
    img = ImageTk.PhotoImage(Image.open("neptun.jpg"))
    panel = Label(windows, image=img)
    panel.pack()
    button = Button(windows, text='Нептун', command=sun)
    button.place(column=0, row=0)
    
def clicked3():  
    root = Tk.Tk()
    root.title('Анимации Солнечной системы')
    lbl2= Tk.Label (root, text='Солнечная система')   
    lbl2.grid(column=0, row=0)
    button1 = Tk.Button(root, text=' показать Солнечную систему', command=func2)
    button1.grid(column=0, row=1)
    button2 = Tk.Button(root, text=' показать планеты Земной группы', command=func3)
    button2.grid(column=0, row=2)
    button3 = Tk.Button(root, text=' показать планеты-гиганты', command=func4)
    button3.grid(column=0, row=3)
    
def clicked4():  
    
    #временные интервалы
    sec_y=365*24*60*60
    sec_d=24*60*60
    years=30
    # определяем переменную величину
    t=np.arange(0,sec_y*years,sec_d*40)
    
    fig = plt.Figure()
    root = Tk.Tk()
    
    #определяем функцию для системы дифферинциальных уравнений
    def grav_func(s,t):
         """
         Функция, определяющая динамику тел двух Солнечных систем
         под влиянием 2 Солнц. Влияние планет друг на друга не учитывается,
         так как является незначительным.
         """
         (x_sun, v_x_sun, y_sun, v_y_sun,
          x_sun2, v_x_sun2, y_sun2, v_y_sun2,
          x_mars, v_x_mars, y_mars, v_y_mars,
          x_ven, v_x_ven, y_ven, v_y_ven,
          x_saturn, v_x_saturn, y_saturn, v_y_saturn,
          x_yup, v_x_yup, y_yup, v_y_yup,
          x_merc, v_x_merc, y_merc, v_y_merc,
          x_earth, v_x_earth, y_earth, v_y_earth,
          x_uran, v_x_uran, y_uran, v_y_uran,
          x_neptun, v_x_neptun, y_neptun, v_y_neptun,
          x_mars2, v_x_mars2, y_mars2, v_y_mars2,
          x_ven2, v_x_ven2, y_ven2, v_y_ven2,
          x_saturn2, v_x_saturn2, y_saturn2, v_y_saturn2,
          x_yup2, v_x_yup2, y_yup2, v_y_yup2,
          x_merc2, v_x_merc2, y_merc2, v_y_merc2,
          x_earth2, v_x_earth2, y_earth2, v_y_earth2,
          x_uran2, v_x_uran2, y_uran2, v_y_uran2,
          x_neptun2, v_x_neptun2, y_neptun2, v_y_neptun2) = s
    
         dxdt_sun2 = v_x_sun2
         dv_xdt_sun2= -G*m_sun* (x_sun2-x_sun)/((x_sun2-x_sun)**2 + (y_sun2-y_sun)**2)**1.5
         dydt_sun2= v_y_sun2
         dv_ydt_sun2=-G*m_sun* (y_sun2-y_sun)/((x_sun2-x_sun)**2 + (y_sun2-y_sun)**2)**1.5
    
         dxdt_sun= v_x_sun
         dv_xdt_sun= -G*m_sun* (x_sun-x_sun2)/((x_sun-x_sun2)**2 + (y_sun-y_sun2)**2)**1.5
         dydt_sun= v_y_sun
         dv_ydt_sun= -G*m_sun* (y_sun-y_sun2)/((x_sun-x_sun2)**2 + (y_sun-y_sun2)**2)**1.5
    
    
         dxdt_mars= v_x_mars
         dv_xdt_mars= (-G*m_sun* (x_mars-x_sun2)/((x_mars-x_sun2)**2 + (y_mars-y_sun2)**2)**1.5
                       -G*m_sun* (x_mars-x_sun)/((x_mars-x_sun)**2 + (y_mars-y_sun)**2)**1.5)
         dydt_mars= v_y_mars
         dv_ydt_mars= (-G*m_sun* (y_mars-y_sun2)/((x_mars-x_sun2)**2 + (y_mars-y_sun2)**2)**1.5
                       -G*m_sun* (y_mars-y_sun)/((x_mars-x_sun)**2 + (y_mars-y_sun)**2)**1.5)
    
    
         dxdt_ven= v_x_ven
         dv_xdt_ven= (-G*m_sun* (x_ven-x_sun2)/((x_ven-x_sun2)**2 + (y_ven-y_sun2)**2)**1.5
                      -G*m_sun* (x_ven-x_sun)/((x_ven-x_sun)**2 + (y_ven-y_sun)**2)**1.5)
         dydt_ven= v_y_ven
         dv_ydt_ven= (-G*m_sun* (y_ven-y_sun2)/((x_ven-x_sun2)**2 + (y_ven-y_sun2)**2)**1.5
                      -G*m_sun* (y_ven-y_sun)/((x_ven-x_sun)**2 + (y_ven-y_sun)**2)**1.5)
    
    
         dxdt_saturn= v_x_saturn
         dv_xdt_saturn= (-G*m_sun* (x_saturn-x_sun2)/((x_saturn-x_sun2)**2 + (y_saturn-y_sun2)**2)**1.5
                         -G*m_sun* (x_saturn-x_sun)/((x_saturn-x_sun)**2 + (y_saturn-y_sun)**2)**1.5)
         dydt_saturn= v_y_saturn
         dv_ydt_saturn= (-G*m_sun* (y_saturn-y_sun2)/((x_saturn-x_sun2)**2 + (y_saturn-y_sun2)**2)**1.5
                         -G*m_sun* (y_saturn-y_sun)/((x_saturn-x_sun)**2 + (y_saturn-y_sun)**2)**1.5)
    
         dxdt_yup= v_x_yup
         dv_xdt_yup= (-G*m_sun* (x_yup-x_sun2)/((x_yup-x_sun2)**2 + (y_yup-y_sun2)**2)**1.5
                      -G*m_sun* (x_yup-x_sun)/((x_yup-x_sun)**2 + (y_yup-y_sun)**2)**1.5)
         dydt_yup= v_y_yup
         dv_ydt_yup= (-G*m_sun* (y_yup-y_sun2)/((x_yup-x_sun2)**2 + (y_yup-y_sun2)**2)**1.5
                      -G*m_sun* (y_yup-y_sun)/((x_yup-x_sun)**2 + (y_yup-y_sun)**2)**1.5)
    
         dxdt_merc= v_x_merc
         dv_xdt_merc= (-G*m_sun* (x_merc-x_sun2)/((x_merc-x_sun2)**2 + (y_merc-y_sun2)**2)**1.5
                       -G*m_sun* (x_merc-x_sun)/((x_merc-x_sun)**2 + (y_merc-y_sun)**2)**1.5)
         dydt_merc= v_y_merc
         dv_ydt_merc= (-G*m_sun* (y_merc-y_sun2)/((x_merc-x_sun2)**2 + (y_merc-y_sun2)**2)**1.5
                       -G*m_sun* (y_merc-y_sun)/((x_merc-x_sun)**2 + (y_merc-y_sun)**2)**1.5)
    
         dxdt_earth= v_x_earth
         dv_xdt_earth= (-G*m_sun* (x_earth-x_sun2)/((x_earth-x_sun2)**2 + (y_earth-y_sun2)**2)**1.5
                        -G*m_sun* (x_earth-x_sun)/((x_earth-x_sun)**2 + (y_earth-y_sun)**2)**1.5)
         dydt_earth= v_y_earth
         dv_ydt_earth= (-G*m_sun* (y_earth-y_sun2)/((x_earth-x_sun2)**2 + (y_earth-y_sun2)**2)**1.5
                        -G*m_sun* (y_earth-y_sun)/((x_earth-x_sun)**2 + (y_earth-y_sun)**2)**1.5)
    
    
         dxdt_uran= v_x_uran
         dv_xdt_uran= (-G*m_sun* (x_uran-x_sun2)/((x_uran-x_sun2)**2 + (y_uran-y_sun2)**2)**1.5
                        -G*m_sun* (x_uran-x_sun)/((x_uran-x_sun)**2 + (y_uran-y_sun)**2)**1.5)
         dydt_uran= v_y_uran
         dv_ydt_uran= (-G*m_sun* (y_uran-y_sun2)/((x_uran-x_sun2)**2 + (y_uran-y_sun2)**2)**1.5
                        -G*m_sun* (y_uran-y_sun)/((x_uran-x_sun)**2 + (y_uran-y_sun)**2)**1.5)
    
    
         dxdt_neptun= v_x_neptun
         dv_xdt_neptun= (-G*m_sun* (x_neptun-x_sun2)/((x_neptun-x_sun2)**2 + (y_neptun-y_sun2)**2)**1.5
                        -G*m_sun* (x_neptun-x_sun)/((x_neptun-x_sun)**2 + (y_neptun-y_sun)**2)**1.5)
         dydt_neptun= v_y_neptun
         dv_ydt_neptun= (-G*m_sun* (y_neptun-y_sun2)/((x_neptun-x_sun2)**2 + (y_neptun-y_sun2)**2)**1.5
                        -G*m_sun* (y_neptun-y_sun)/((x_neptun-x_sun)**2 + (y_neptun-y_sun)**2)**1.5)
    
    
         dxdt_mars2= v_x_mars2
         dv_xdt_mars2= (-G*m_sun* (x_mars2-x_sun2)/((x_mars2-x_sun2)**2 + (y_mars2-y_sun2)**2)**1.5
                       -G*m_sun* (x_mars2-x_sun)/((x_mars2-x_sun)**2 + (y_mars2-y_sun)**2)**1.5)
         dydt_mars2= v_y_mars2
         dv_ydt_mars2= (-G*m_sun* (y_mars2-y_sun2)/((x_mars2-x_sun2)**2 + (y_mars2-y_sun2)**2)**1.5
                       -G*m_sun* (y_mars2-y_sun)/((x_mars2-x_sun)**2 + (y_mars2-y_sun)**2)**1.5)
    
    
         dxdt_ven2= v_x_ven2
         dv_xdt_ven2= (-G*m_sun* (x_ven2-x_sun2)/((x_ven2-x_sun2)**2 + (y_ven2-y_sun2)**2)**1.5
                      -G*m_sun* (x_ven2-x_sun)/((x_ven2-x_sun)**2 + (y_ven2-y_sun)**2)**1.5)
         dydt_ven2= v_y_ven2
         dv_ydt_ven2= (-G*m_sun* (y_ven2-y_sun2)/((x_ven2-x_sun2)**2 + (y_ven2-y_sun2)**2)**1.5
                      -G*m_sun* (y_ven2-y_sun)/((x_ven2-x_sun)**2 + (y_ven2-y_sun)**2)**1.5)
    
    
         dxdt_saturn2= v_x_saturn2
         dv_xdt_saturn2= (-G*m_sun* (x_saturn2-x_sun2)/((x_saturn2-x_sun2)**2 + (y_saturn2-y_sun2)**2)**1.5
                         -G*m_sun* (x_saturn2-x_sun)/((x_saturn2-x_sun)**2 + (y_saturn2-y_sun)**2)**1.5)
         dydt_saturn2= v_y_saturn2
         dv_ydt_saturn2= (-G*m_sun* (y_saturn2-y_sun2)/((x_saturn2-x_sun2)**2 + (y_saturn2-y_sun2)**2)**1.5
                         -G*m_sun* (y_saturn2-y_sun)/((x_saturn2-x_sun)**2 + (y_saturn2-y_sun)**2)**1.5)
    
         dxdt_yup2= v_x_yup2
         dv_xdt_yup2= (-G*m_sun* (x_yup2-x_sun2)/((x_yup2-x_sun2)**2 + (y_yup2-y_sun2)**2)**1.5
                      -G*m_sun* (x_yup2-x_sun)/((x_yup2-x_sun)**2 + (y_yup2-y_sun)**2)**1.5)
         dydt_yup2= v_y_yup2
         dv_ydt_yup2= (-G*m_sun* (y_yup2-y_sun2)/((x_yup2-x_sun2)**2 + (y_yup2-y_sun2)**2)**1.5
                      -G*m_sun* (y_yup2-y_sun)/((x_yup2-x_sun)**2 + (y_yup2-y_sun)**2)**1.5)
    
         dxdt_merc2= v_x_merc2
         dv_xdt_merc2= (-G*m_sun* (x_merc2-x_sun2)/((x_merc2-x_sun2)**2 + (y_merc2-y_sun2)**2)**1.5
                       -G*m_sun* (x_merc2-x_sun)/((x_merc2-x_sun)**2 + (y_merc2-y_sun)**2)**1.5)
         dydt_merc2= v_y_merc2
         dv_ydt_merc2= (-G*m_sun* (y_merc2-y_sun2)/((x_merc2-x_sun2)**2 + (y_merc2-y_sun2)**2)**1.5
                       -G*m_sun* (y_merc2-y_sun)/((x_merc2-x_sun)**2 + (y_merc2-y_sun)**2)**1.5)
    
         dxdt_earth2= v_x_earth2
         dv_xdt_earth2= (-G*m_sun* (x_earth2-x_sun2)/((x_earth2-x_sun2)**2 + (y_earth2-y_sun2)**2)**1.5
                        -G*m_sun* (x_earth2-x_sun)/((x_earth2-x_sun)**2 + (y_earth2-y_sun)**2)**1.5)
         dydt_earth2= v_y_earth2
         dv_ydt_earth2= (-G*m_sun* (y_earth2-y_sun2)/((x_earth2-x_sun2)**2 + (y_earth2-y_sun2)**2)**1.5
                        -G*m_sun* (y_earth2-y_sun)/((x_earth2-x_sun)**2 + (y_earth2-y_sun)**2)**1.5)
    
    
         dxdt_uran2= v_x_uran2
         dv_xdt_uran2= (-G*m_sun* (x_uran2-x_sun2)/((x_uran2-x_sun2)**2 + (y_uran2-y_sun2)**2)**1.5
                        -G*m_sun* (x_uran2-x_sun)/((x_uran2-x_sun)**2 + (y_uran2-y_sun)**2)**1.5)
         dydt_uran2= v_y_uran2
         dv_ydt_uran2= (-G*m_sun* (y_uran2-y_sun2)/((x_uran2-x_sun2)**2 + (y_uran2-y_sun2)**2)**1.5
                        -G*m_sun* (y_uran2-y_sun)/((x_uran2-x_sun)**2 + (y_uran2-y_sun)**2)**1.5)
    
    
         dxdt_neptun2= v_x_neptun2
         dv_xdt_neptun2= (-G*m_sun* (x_neptun2-x_sun2)/((x_neptun2-x_sun2)**2 + (y_neptun2-y_sun2)**2)**1.5
                        -G*m_sun* (x_neptun2-x_sun)/((x_neptun2-x_sun)**2 + (y_neptun2-y_sun)**2)**1.5)
         dydt_neptun2= v_y_neptun2
         dv_ydt_neptun2= (-G*m_sun* (y_neptun2-y_sun2)/((x_neptun2-x_sun2)**2 + (y_neptun2-y_sun2)**2)**1.5
                        -G*m_sun* (y_neptun2-y_sun)/((x_neptun2-x_sun)**2 + (y_neptun2-y_sun)**2)**1.5)
    
    
    
         return(dxdt_sun, dv_xdt_sun, dydt_sun, dv_ydt_sun,
                dxdt_sun2,dv_xdt_sun2, dydt_sun2, dv_ydt_sun2,
                dxdt_mars, dv_xdt_mars, dydt_mars, dv_ydt_mars,
                dxdt_ven, dv_xdt_ven, dydt_ven, dv_ydt_ven,
                dxdt_saturn,dv_xdt_saturn, dydt_saturn, dv_ydt_saturn,
                dxdt_yup,dv_xdt_yup,dydt_yup, dv_ydt_yup,
                dxdt_merc, dv_xdt_merc, dydt_merc, dv_ydt_merc,
                dxdt_earth, dv_xdt_earth, dydt_earth, dv_ydt_earth,
                dxdt_uran, dv_xdt_uran, dydt_uran, dv_ydt_uran,
                dxdt_neptun, dv_xdt_neptun, dydt_neptun, dv_ydt_neptun,
                dxdt_mars2, dv_xdt_mars2, dydt_mars2, dv_ydt_mars2,
                dxdt_ven2, dv_xdt_ven2, dydt_ven2, dv_ydt_ven2,
                dxdt_saturn2,dv_xdt_saturn2, dydt_saturn2, dv_ydt_saturn2,
                dxdt_yup2,dv_xdt_yup2,dydt_yup2, dv_ydt_yup2,
                dxdt_merc2, dv_xdt_merc2, dydt_merc2, dv_ydt_merc2,
                dxdt_earth2, dv_xdt_earth2, dydt_earth2, dv_ydt_earth2,
                dxdt_uran2, dv_xdt_uran2, dydt_uran2, dv_ydt_uran2,
                dxdt_neptun2, dv_xdt_neptun2, dydt_neptun2, dv_ydt_neptun2)

    #Определяем начальные значения и параметры, входящие в систему диф. уравнений
    m_sun=1.98847*10**30
    m_mars=6.39*10**23
    m_ven=4.867*10**24
    m_saturn=5.683*10**26
    m_yup=1.898*10**27
    m_merc=3.285*10**23
    m_earth=5.972*10**24
    m_uran=8.681*10**25
    m_neptun=1.024*10**26
    G=6.67*10**(-11)
    
    n=10**12 # расстояние между Солнечными системами
    
    x_sun0=0
    v_x_sun0=10**3
    y_sun0=0
    v_y_sun0=0
    
    x_sun20=0+n
    v_x_sun20=-10**3
    y_sun20=0
    v_y_sun20=0
    
    x0_mars=-228*10**9
    v_x0_mars=0
    y0_mars=0
    v_y0_mars=24100
    
    x0_ven=-108*10**9
    v_x0_ven=0
    y0_ven=0
    v_y0_ven=35000
    
    x0_saturn=-1430*10**9
    v_x0_saturn=0
    y0_saturn=0
    v_y0_saturn=9690
    
    x0_yup=-778.57*10**9
    v_x0_yup=0
    y0_yup=0
    v_y0_yup=13070
    
    x0_merc=-58*10**9
    v_x0_merc=0
    y0_merc=0
    v_y0_merc=48000
    
    x0_earth=-150*10**9
    v_x0_earth=0
    y0_earth=0
    v_y0_earth=30000
    
    
    x0_uran=-2875*10**9
    v_x0_uran=0
    y0_uran=0
    v_y0_uran=7000
    
    x0_neptun=-4497*10**9
    v_x0_neptun=0
    y0_neptun=0
    v_y0_neptun=5000
    
    
    x0_mars2=(228*10**9)+n
    v_x0_mars2=0
    y0_mars2=0
    v_y0_mars2=-4100
    
    x0_ven2=(108*10**9)+n
    v_x0_ven2=0
    y0_ven2=0
    v_y0_ven2=-35000
    
    x0_saturn2=(1430*10**9)+n
    v_x0_saturn2=0
    y0_saturn2=0
    v_y0_saturn2=-9690
    
    x0_yup2=(778.57*10**9)+n
    v_x0_yup2=0
    y0_yup2=0
    v_y0_yup2=-13070
    
    x0_merc2=(58*10**9)+n
    v_x0_merc2=0
    y0_merc2=0
    v_y0_merc2=-48000
    
    x0_earth2=(150*10**9)+n
    v_x0_earth2=0
    y0_earth2=0
    v_y0_earth2=-30000
    
    
    x0_uran2=(2875*10**9)+n
    v_x0_uran2=0
    y0_uran2=0
    v_y0_uran2=-7000
    
    x0_neptun2=(4497*10**9)+n
    v_x0_neptun2=0
    y0_neptun2=0
    v_y0_neptun2=-5000
    
    r_sun=696.34*10**6
    r_mars=3.3895*10**6
    r_ven=6.0518*10**6
    r_saturn=58.232*10**6
    r_yup=69.911*10**6
    r_merc=2.4397*10**6
    r_earth=6.371*10**6
    r_uran=25.362*10**6
    r_neptun=24.622*10**6
    
    
    s0= (x_sun0, v_x_sun0, y_sun0,v_y_sun0,
         x_sun20, v_x_sun20, y_sun20, v_y_sun20,
         x0_mars,v_x0_mars,y0_mars, v_y0_mars,
        x0_ven,v_x0_ven, y0_ven,v_y0_ven,
        x0_saturn, v_x0_saturn,y0_saturn,v_y0_saturn,
        x0_yup, v_x0_yup, y0_yup, v_y0_yup,
        x0_merc, v_x0_merc, y0_merc, v_y0_merc,
        x0_earth, v_x0_earth, y0_earth, v_y0_earth,
        x0_uran, v_x0_uran, y0_uran, v_y0_uran,
        x0_neptun, v_x0_neptun, y0_neptun, v_y0_neptun,
        x0_mars2,v_x0_mars2,y0_mars2, v_y0_mars2,
        x0_ven2,v_x0_ven2, y0_ven2,v_y0_ven2,
        x0_saturn2, v_x0_saturn2,y0_saturn2,v_y0_saturn2,
        x0_yup2, v_x0_yup2, y0_yup2, v_y0_yup2,
        x0_merc2, v_x0_merc2, y0_merc2, v_y0_merc2,
        x0_earth2, v_x0_earth2, y0_earth2, v_y0_earth2,
        x0_uran2, v_x0_uran2, y0_uran2, v_y0_uran2,
        x0_neptun2, v_x0_neptun2, y0_neptun2, v_y0_neptun2)
    
    move_array=np.ndarray(shape=(len(t), 36))
    for i in range(len(t)-1):
        tau= [t[i], t[i+1]] #разбиваем всё время t на маленькие промежутки tau
    
        sol=odeint(grav_func, s0, tau) #решаем систему диф.уравнений
        #записываем координаты новых положений в массив
        move_array[i,0]= sol[1,0]
        move_array[i,1]= sol[1,2]
        move_array[i,2]= sol[1,4]
        move_array[i,3]= sol[1,6]
        move_array[i,4]= sol[1,8]
        move_array[i,5]= sol[1,10]
        move_array[i,6]= sol[1,12]
        move_array[i,7]= sol[1,14]
        move_array[i,8]= sol[1,16]
        move_array[i,9]= sol[1,18]
        move_array[i,10]= sol[1,20]
        move_array[i,11]= sol[1,22]
        move_array[i,12]= sol[1,24]
        move_array[i,13]= sol[1,26]
        move_array[i,14]= sol[1,28]
        move_array[i,15]= sol[1,30]
        move_array[i,16]= sol[1,32]
        move_array[i,17]= sol[1,34]
        move_array[i,18]= sol[1,36]
        move_array[i,19]= sol[1,38]
        move_array[i,20]= sol[1,40]
        move_array[i,21]= sol[1,42]
        move_array[i,22]= sol[1,44]
        move_array[i,23]= sol[1,46]
        move_array[i,24]= sol[1,48]
        move_array[i,25]= sol[1,50]
        move_array[i,26]= sol[1,52]
        move_array[i,27]= sol[1,54]
        move_array[i,28]= sol[1,56]
        move_array[i,29]= sol[1,58]
        move_array[i,30]= sol[1,60]
        move_array[i,31]= sol[1,62]
        move_array[i,32]= sol[1,64]
        move_array[i,33]= sol[1,66]
        move_array[i,34]= sol[1,68]
        move_array[i,35]= sol[1,70]
        #определённые положения и скорости становятся
        #начальными условиями для следующего промежутка tau
        x_sun0=sol[1,0]
        v_x_sun0=sol[1,1]
        y_sun0=sol[1,2]
        v_y_sun0=sol[1,3]
    
        x_sun20=sol[1,4]
        v_x_sun20=sol[1,5]
        y_sun20=sol[1,6]
        v_y_sun20=sol[1,7]
    
        x0_mars=sol[1,8]
        v_x0_mars=sol[1,9]
        y0_mars=sol[1,10]
        v_y0_mars=sol[1,11]
    
        x0_ven=sol[1,12]
        v_x0_ven=sol[1,13]
        y0_ven=sol[1,14]
        v_y0_ven=sol[1,15]
    
        x0_saturn=sol[1,16]
        v_x0_saturn=sol[1,17]
        y0_saturn=sol[1,18]
        v_y0_saturn=sol[1,19]
    
        x0_yup=sol[1,20]
        v_x0_yup=sol[1,21]
        y0_yup=sol[1,22]
        v_y0_yup=sol[1,23]
    
        x0_merc=sol[1,24]
        v_x0_merc=sol[1,25]
        y0_merc=sol[1,26]
        v_y0_merc=sol[1,27]
    
        x0_earth=sol[1,28]
        v_x0_earth=sol[1,29]
        y0_earth=sol[1,30]
        v_y0_earth=sol[1,31]
    
        x0_uran=sol[1,32]
        v_x0_uran=sol[1,33]
        y0_uran=sol[1,34]
        v_y0_uran=sol[1,35]
    
        x0_neptun=sol[1,36]
        v_x0_neptun=sol[1,37]
        y0_neptun=sol[1,38]
        v_y0_neptun=sol[1,39]
    
    
        x0_mars2=sol[1,40]
        v_x0_mars2=sol[1,41]
        y0_mars2=sol[1,42]
        v_y0_mars2=sol[1,43]
    
        x0_ven2=sol[1,44]
        v_x0_ven2=sol[1,45]
        y0_ven2=sol[1,46]
        v_y0_ven2=sol[1, 47]
    
        x0_saturn2=sol[1,48]
        v_x0_saturn2=sol[1,49]
        y0_saturn2=sol[1,50]
        v_y0_saturn2=sol[1,51]
    
        x0_yup2=sol[1,52]
        v_x0_yup2=sol[1,53]
        y0_yup2=sol[1,54]
        v_y0_yup2=sol[1,55]
    
        x0_merc2=sol[1,56]
        v_x0_merc2=sol[1,57]
        y0_merc2=sol[1,58]
        v_y0_merc2=sol[1,59]
    
        x0_earth2=sol[1,60]
        v_x0_earth2=sol[1,61]
        y0_earth2=sol[1,62]
        v_y0_earth2=sol[1,63]
    
    
        x0_uran2=sol[1,64]
        v_x0_uran2=sol[1,65]
        y0_uran2=sol[1,66]
        v_y0_uran2=sol[1,67]
    
        x0_neptun2=sol[1,68]
        v_x0_neptun2=sol[1,69]
        y0_neptun2=sol[1,70]
        v_y0_neptun2=sol[1,71]
        #проверка на столкновение и пересчёт условий
        rsun_sun2= np.sqrt((x_sun0-x_sun20)**2+(y_sun0-y_sun20)**2)
        rsun_mars= np.sqrt((x_sun0-x0_mars)**2+(y_sun0-y0_mars)**2)
        rsun_ven= np.sqrt((x_sun0-x0_ven)**2+(y_sun0-y0_ven)**2)
        rsun_saturn= np.sqrt((x_sun0-x0_saturn)**2+(y_sun0-y0_saturn)**2)
        rsun_yup= np.sqrt((x_sun0-x0_yup)**2+(y_sun0-y0_yup)**2)
        rsun_merc= np.sqrt((x_sun0-x0_merc)**2+(y_sun0-y0_merc)**2)
        rsun_earth= np.sqrt((x_sun0-x0_earth)**2+(y_sun0-y0_earth)**2)
        rsun_uran= np.sqrt((x_sun0-x0_uran)**2+(y_sun0-y0_uran)**2)
        rsun_neptun= np.sqrt((x_sun0-x0_neptun)**2+(y_sun0-y0_neptun)**2)
        rsun_mars2= np.sqrt((x_sun0-x0_mars2)**2+(y_sun0-y0_mars2)**2)
        rsun_ven2= np.sqrt((x_sun0-x0_ven2)**2+(y_sun0-y0_ven2)**2)
        rsun_saturn2= np.sqrt((x_sun0-x0_saturn2)**2+(y_sun0-y0_saturn2)**2)
        rsun_yup2= np.sqrt((x_sun0-x0_yup2)**2+(y_sun0-y0_yup2)**2)
        rsun_merc2= np.sqrt((x_sun0-x0_merc2)**2+(y_sun0-y0_merc2)**2)
        rsun_earth2= np.sqrt((x_sun0-x0_earth2)**2+(y_sun0-y0_earth2)**2)
        rsun_uran2= np.sqrt((x_sun0-x0_uran2)**2+(y_sun0-y0_uran2)**2)
        rsun_neptun2= np.sqrt((x_sun0-x0_neptun2)**2+(y_sun0-y0_neptun2)**2)

        rmars_sun2= np.sqrt((x0_mars-x_sun20)**2+(y0_mars-y_sun20)**2)
        rmars_ven= np.sqrt((x0_mars-x0_ven)**2+(y0_mars-y0_ven)**2)
        rmars_saturn= np.sqrt((x0_mars-x0_saturn)**2+(y0_mars-y0_saturn)**2)
        rmars_yup= np.sqrt((x0_mars-x0_yup)**2+(y0_mars-y0_yup)**2)
        rmars_merc= np.sqrt((x0_mars-x0_merc)**2+(y0_mars-y0_merc)**2)
        rmars_earth= np.sqrt((x0_mars-x0_earth)**2+(y0_mars-y0_earth)**2)
        rmars_uran= np.sqrt((x0_mars-x0_uran)**2+(y0_mars-y0_uran)**2)
        rmars_neptun= np.sqrt((x0_mars-x0_neptun)**2+(y0_mars-y0_neptun)**2)
        rmars_mars2= np.sqrt((x0_mars-x0_mars2)**2+(y0_mars-y0_mars2)**2)
        rmars_ven2= np.sqrt((x0_mars-x0_ven2)**2+(y0_mars-y0_ven2)**2)
        rmars_saturn2= np.sqrt((x0_mars-x0_saturn2)**2+(y0_mars-y0_saturn2)**2)
        rmars_yup2= np.sqrt((x0_mars-x0_yup2)**2+(y0_mars-y0_yup2)**2)
        rmars_merc2= np.sqrt((x0_mars-x0_merc2)**2+(y0_mars-y0_merc2)**2)
        rmars_earth2= np.sqrt((x0_mars-x0_earth2)**2+(y0_mars-y0_earth2)**2)
        rmars_uran2= np.sqrt((x0_mars-x0_uran2)**2+(y0_mars-y0_uran2)**2)
        rmars_neptun2= np.sqrt((x0_mars-x0_neptun2)**2+(y0_mars-y0_neptun2)**2)
    
        rven_sun2= np.sqrt((x0_ven-x_sun20)**2+(y0_ven-y_sun20)**2)
        rven_saturn= np.sqrt((x0_ven-x0_saturn)**2+(y0_ven-y0_saturn)**2)
        rven_yup= np.sqrt((x0_ven-x0_yup)**2+(y0_ven-y0_yup)**2)
        rven_merc= np.sqrt((x0_ven-x0_merc)**2+(y0_ven-y0_merc)**2)
        rven_earth= np.sqrt((x0_ven-x0_earth)**2+(y0_ven-y0_earth)**2)
        rven_uran= np.sqrt((x0_ven-x0_uran)**2+(y0_ven-y0_uran)**2)
        rven_neptun= np.sqrt((x0_ven-x0_neptun)**2+(y0_ven-y0_neptun)**2)
        rven_mars2= np.sqrt((x0_ven-x0_mars2)**2+(y0_ven-y0_mars2)**2)
        rven_ven2= np.sqrt((x0_ven-x0_ven2)**2+(y0_ven-y0_ven2)**2)
        rven_saturn2= np.sqrt((x0_ven-x0_saturn2)**2+(y0_ven-y0_saturn2)**2)
        rven_yup2= np.sqrt((x0_ven-x0_yup2)**2+(y0_ven-y0_yup2)**2)
        rven_merc2= np.sqrt((x0_ven-x0_merc2)**2+(y0_ven-y0_merc2)**2)
        rven_earth2= np.sqrt((x0_ven-x0_earth2)**2+(y0_ven-y0_earth2)**2)
        rven_uran2= np.sqrt((x0_ven-x0_uran2)**2+(y0_ven-y0_uran2)**2)
        rven_neptun2= np.sqrt((x0_ven-x0_neptun2)**2+(y0_ven-y0_neptun2)**2)
    
        rsaturn_sun2= np.sqrt((x0_saturn-x_sun20)**2+(y0_saturn-y_sun20)**2)
        rsaturn_yup= np.sqrt((x0_saturn-x0_yup)**2+(y0_saturn-y0_yup)**2)
        rsaturn_merc= np.sqrt((x0_saturn-x0_merc)**2+(y0_saturn-y0_merc)**2)
        rsaturn_earth= np.sqrt((x0_saturn-x0_earth)**2+(y0_saturn-y0_earth)**2)
        rsaturn_uran= np.sqrt((x0_saturn-x0_uran)**2+(y0_saturn-y0_uran)**2)
        rsaturn_neptun= np.sqrt((x0_saturn-x0_neptun)**2+(y0_saturn-y0_neptun)**2)
        rsaturn_mars2= np.sqrt((x0_saturn-x0_mars2)**2+(y0_saturn-y0_mars2)**2)
        rsaturn_ven2= np.sqrt((x0_saturn-x0_ven2)**2+(y0_saturn-y0_ven2)**2)
        rsaturn_saturn2= np.sqrt((x0_saturn-x0_saturn2)**2+(y0_saturn-y0_saturn2)**2)
        rsaturn_yup2= np.sqrt((x0_saturn-x0_yup2)**2+(y0_saturn-y0_yup2)**2)
        rsaturn_merc2= np.sqrt((x0_saturn-x0_merc2)**2+(y0_saturn-y0_merc2)**2)
        rsaturn_earth2= np.sqrt((x0_saturn-x0_earth2)**2+(y0_saturn-y0_earth2)**2)
        rsaturn_uran2= np.sqrt((x0_saturn-x0_uran2)**2+(y0_saturn-y0_uran2)**2)
        rsaturn_neptun2= np.sqrt((x0_saturn-x0_neptun2)**2+(y0_saturn-y0_neptun2)**2)
    
        ryup_sun2= np.sqrt((x0_yup-x_sun20)**2+(y0_yup-y_sun20)**2)
        ryup_yup= np.sqrt((x0_yup-x0_yup)**2+(y0_yup-y0_yup)**2)
        ryup_merc= np.sqrt((x0_yup-x0_merc)**2+(y0_yup-y0_merc)**2)
        ryup_earth= np.sqrt((x0_yup-x0_earth)**2+(y0_yup-y0_earth)**2)
        ryup_uran= np.sqrt((x0_yup-x0_uran)**2+(y0_yup-y0_uran)**2)
        ryup_neptun= np.sqrt((x0_yup-x0_neptun)**2+(y0_yup-y0_neptun)**2)
        ryup_mars2= np.sqrt((x0_yup-x0_mars2)**2+(y0_yup-y0_mars2)**2)
        ryup_ven2= np.sqrt((x0_yup-x0_ven2)**2+(y0_yup-y0_ven2)**2)
        ryup_saturn2= np.sqrt((x0_yup-x0_saturn2)**2+(y0_yup-y0_saturn2)**2)
        ryup_yup2= np.sqrt((x0_yup-x0_yup2)**2+(y0_yup-y0_yup2)**2)
        ryup_merc2= np.sqrt((x0_yup-x0_merc2)**2+(y0_yup-y0_merc2)**2)
        ryup_earth2= np.sqrt((x0_yup-x0_earth2)**2+(y0_yup-y0_earth2)**2)
        ryup_uran2= np.sqrt((x0_yup-x0_uran2)**2+(y0_yup-y0_uran2)**2)
        ryup_neptun2= np.sqrt((x0_yup-x0_neptun2)**2+(y0_yup-y0_neptun2)**2)
    
        rmerc_sun2= np.sqrt((x0_merc-x_sun20)**2+(y0_merc-y_sun20)**2)
        rmerc_earth= np.sqrt((x0_merc-x0_earth)**2+(y0_merc-y0_earth)**2)
        rmerc_uran= np.sqrt((x0_merc-x0_uran)**2+(y0_merc-y0_uran)**2)
        rmerc_neptun= np.sqrt((x0_merc-x0_neptun)**2+(y0_merc-y0_neptun)**2)
        rmerc_mars2= np.sqrt((x0_merc-x0_mars2)**2+(y0_merc-y0_mars2)**2)
        rmerc_ven2= np.sqrt((x0_merc-x0_ven2)**2+(y0_merc-y0_ven2)**2)
        rmerc_saturn2= np.sqrt((x0_merc-x0_saturn2)**2+(y0_merc-y0_saturn2)**2)
        rmerc_yup2= np.sqrt((x0_merc-x0_yup2)**2+(y0_merc-y0_yup2)**2)
        rmerc_merc2= np.sqrt((x0_merc-x0_merc2)**2+(y0_merc-y0_merc2)**2)
        rmerc_earth2= np.sqrt((x0_merc-x0_earth2)**2+(y0_merc-y0_earth2)**2)
        rmerc_uran2= np.sqrt((x0_merc-x0_uran2)**2+(y0_merc-y0_uran2)**2)
        rmerc_neptun2= np.sqrt((x0_merc-x0_neptun2)**2+(y0_merc-y0_neptun2)**2)
    
        rearth_sun2= np.sqrt((x0_earth-x_sun20)**2+(y0_earth-y_sun20)**2)
        rearth_uran= np.sqrt((x0_earth-x0_uran)**2+(y0_earth-y0_uran)**2)
        rearth_neptun= np.sqrt((x0_earth-x0_neptun)**2+(y0_earth-y0_neptun)**2)
        rearth_mars2= np.sqrt((x0_earth-x0_mars2)**2+(y0_earth-y0_mars2)**2)
        rearth_ven2= np.sqrt((x0_earth-x0_ven2)**2+(y0_earth-y0_ven2)**2)
        rearth_saturn2= np.sqrt((x0_earth-x0_saturn2)**2+(y0_earth-y0_saturn2)**2)
        rearth_yup2= np.sqrt((x0_earth-x0_yup2)**2+(y0_earth-y0_yup2)**2)
        rearth_merc2= np.sqrt((x0_earth-x0_merc2)**2+(y0_earth-y0_merc2)**2)
        rearth_earth2= np.sqrt((x0_earth-x0_earth2)**2+(y0_earth-y0_earth2)**2)
        rearth_uran2= np.sqrt((x0_earth-x0_uran2)**2+(y0_earth-y0_uran2)**2)
        rearth_neptun2= np.sqrt((x0_earth-x0_neptun2)**2+(y0_earth-y0_neptun2)**2)
    
        ruran_sun2= np.sqrt((x0_uran-x_sun20)**2+(y0_uran-y_sun20)**2)
        ruran_neptun= np.sqrt((x0_uran-x0_neptun)**2+(y0_uran-y0_neptun)**2)
        ruran_mars2= np.sqrt((x0_uran-x0_mars2)**2+(y0_uran-y0_mars2)**2)
        ruran_ven2= np.sqrt((x0_uran-x0_ven2)**2+(y0_uran-y0_ven2)**2)
        ruran_saturn2= np.sqrt((x0_uran-x0_saturn2)**2+(y0_uran-y0_saturn2)**2)
        ruran_yup2= np.sqrt((x0_uran-x0_yup2)**2+(y0_uran-y0_yup2)**2)
        ruran_merc2= np.sqrt((x0_uran-x0_merc2)**2+(y0_uran-y0_merc2)**2)
        ruran_earth2= np.sqrt((x0_uran-x0_earth2)**2+(y0_uran-y0_earth2)**2)
        ruran_uran2= np.sqrt((x0_uran-x0_uran2)**2+(y0_uran-y0_uran2)**2)
        ruran_neptun2= np.sqrt((x0_uran-x0_neptun2)**2+(y0_uran-y0_neptun2)**2)
    
        rneptun_sun2= np.sqrt((x0_neptun-x_sun20)**2+(y0_neptun-y_sun20)**2)
        rneptun_mars2= np.sqrt((x0_neptun-x0_mars2)**2+(y0_neptun-y0_mars2)**2)
        rneptun_ven2= np.sqrt((x0_neptun-x0_ven2)**2+(y0_neptun-y0_ven2)**2)
        rneptun_saturn2= np.sqrt((x0_neptun-x0_saturn2)**2+(y0_neptun-y0_saturn2)**2)
        rneptun_yup2= np.sqrt((x0_neptun-x0_yup2)**2+(y0_neptun-y0_yup2)**2)
        rneptun_merc2= np.sqrt((x0_neptun-x0_merc2)**2+(y0_neptun-y0_merc2)**2)
        rneptun_earth2= np.sqrt((x0_neptun-x0_earth2)**2+(y0_neptun-y0_earth2)**2)
        rneptun_uran2= np.sqrt((x0_neptun-x0_uran2)**2+(y0_neptun-y0_uran2)**2)
        rneptun_neptun2= np.sqrt((x0_neptun-x0_neptun2)**2+(y0_neptun-y0_neptun2)**2)
    
        rmars2_sun2= np.sqrt((x0_mars2-x_sun20)**2+(y0_mars2-y_sun20)**2)
        rmars2_ven2= np.sqrt((x0_mars2-x0_ven2)**2+(y0_mars2-y0_ven2)**2)
        rmars2_saturn2= np.sqrt((x0_mars2-x0_saturn2)**2+(y0_mars2-y0_saturn2)**2)
        rmars2_yup2= np.sqrt((x0_mars2-x0_yup2)**2+(y0_mars2-y0_yup2)**2)
        rmars2_merc2= np.sqrt((x0_mars2-x0_merc2)**2+(y0_mars2-y0_merc2)**2)
        rmars2_earth2= np.sqrt((x0_mars2-x0_earth2)**2+(y0_mars2-y0_earth2)**2)
        rmars2_uran2= np.sqrt((x0_mars2-x0_uran2)**2+(y0_mars2-y0_uran2)**2)
        rmars2_neptun2= np.sqrt((x0_mars2-x0_neptun2)**2+(y0_mars2-y0_neptun2)**2)
    
        rven2_sun2= np.sqrt((x0_ven2-x_sun20)**2+(y0_ven2-y_sun20)**2)
        rven2_saturn2= np.sqrt((x0_ven2-x0_saturn2)**2+(y0_ven2-y0_saturn2)**2)
        rven2_yup2= np.sqrt((x0_ven2-x0_yup2)**2+(y0_ven2-y0_yup2)**2)
        rven2_merc2= np.sqrt((x0_ven2-x0_merc2)**2+(y0_ven2-y0_merc2)**2)
        rven2_earth2= np.sqrt((x0_ven2-x0_earth2)**2+(y0_ven2-y0_earth2)**2)
        rven2_uran2= np.sqrt((x0_ven2-x0_uran2)**2+(y0_ven2-y0_uran2)**2)
        rven2_neptun2= np.sqrt((x0_ven2-x0_neptun2)**2+(y0_ven2-y0_neptun2)**2)
    
        rsaturn2_sun2= np.sqrt((x0_saturn2-x_sun20)**2+(y0_saturn2-y_sun20)**2)
        rsaturn2_yup2= np.sqrt((x0_saturn2-x0_yup2)**2+(y0_saturn2-y0_yup2)**2)
        rsaturn2_merc2= np.sqrt((x0_saturn2-x0_merc2)**2+(y0_saturn2-y0_merc2)**2)
        rsaturn2_earth2= np.sqrt((x0_saturn2-x0_earth2)**2+(y0_saturn2-y0_earth2)**2)
        rsaturn2_uran2= np.sqrt((x0_saturn2-x0_uran2)**2+(y0_saturn2-y0_uran2)**2)
        rsaturn2_neptun2= np.sqrt((x0_saturn2-x0_neptun2)**2+(y0_saturn2-y0_neptun2)**2)
    
        ryup2_sun2= np.sqrt((x0_yup2-x_sun20)**2+(y0_yup2-y_sun20)**2)
        ryup2_merc2= np.sqrt((x0_yup2-x0_merc2)**2+(y0_yup2-y0_merc2)**2)
        ryup2_earth2= np.sqrt((x0_yup2-x0_earth2)**2+(y0_yup2-y0_earth2)**2)
        ryup2_uran2= np.sqrt((x0_yup2-x0_uran2)**2+(y0_yup2-y0_uran2)**2)
        ryup2_neptun2= np.sqrt((x0_yup2-x0_neptun2)**2+(y0_yup2-y0_neptun2)**2)
    
        rmerc2_sun2= np.sqrt((x0_merc2-x_sun20)**2+(y0_merc2-y_sun20)**2)
        rmerc2_earth2= np.sqrt((x0_merc2-x0_earth2)**2+(y0_merc2-y0_earth2)**2)
        rmerc2_uran2= np.sqrt((x0_merc2-x0_uran2)**2+(y0_merc2-y0_uran2)**2)
        rmerc2_neptun2= np.sqrt((x0_merc2-x0_neptun2)**2+(y0_merc2-y0_neptun2)**2)
    
        rearth2_sun2= np.sqrt((x0_earth2-x_sun20)**2+(y0_earth2-y_sun20)**2)
        rearth2_uran2= np.sqrt((x0_earth2-x0_uran2)**2+(y0_earth2-y0_uran2)**2)
        rearth2_neptun2= np.sqrt((x0_earth2-x0_neptun2)**2+(y0_earth2-y0_neptun2)**2)
    
        ruran2_sun2= np.sqrt((x0_uran2-x_sun20)**2+(y0_uran2-y_sun20)**2)
        ruran2_neptun2= np.sqrt((x0_uran2-x0_neptun2)**2+(y0_uran2-y0_neptun2)**2)
    
        rneptun2_sun2= np.sqrt((x0_neptun2-x_sun20)**2+(y0_neptun2-y_sun20)**2)
    
        if rsun_sun2 <= r_sun+r_sun:
            V_x_sun0=(2*m_sun*v_x_sun20+v_x_sun0*(m_sun-m_sun) )/(m_sun+m_sun)
            V_x_sun20=(2*m_sun*v_x_sun0+v_x_sun20*(m_sun-m_sun) )/(m_sun+m_sun)
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsun_mars <=  r_sun+r_mars:
            V_x_sun0=(2*m_mars*v_y0_mars+v_x_sun0*(m_sun-m_mars) )/(m_sun+m_mars)
            V_y0_mars=(2*m_sun*v_x_sun0+v_y0_mars*(m_mars-m_sun) )/(m_sun+m_mars)
            V_x_sun20= v_x_sun20
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsun_ven <= r_sun+r_ven:
            V_x_sun0=(2*m_ven*v_y0_ven+v_x_sun0*(m_sun-m_ven) )/(m_sun+m_ven)
            V_y0_ven=(2*m_sun*v_x_sun0+v_y0_ven*(m_ven-m_sun) )/(m_sun+m_ven)
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsun_saturn <= r_sun+r_saturn:
            V_x_sun0=(2*m_saturn*v_y0_saturn+v_x_sun0*(m_sun-m_saturn) )/(m_sun+m_saturn)
            V_y0_saturn=(2*m_sun*v_x_sun0+v_y0_saturn*(m_saturn-m_sun) )/(m_sun+m_saturn)
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsun_yup <= r_sun+r_yup:
            Vx_sun0=(2*m_yup*v_y0_yup+v_x_sun0*(m_sun-m_yup) )/(m_sun+m_yup)
            V_y0_yup=(2*m_sun*v_x_sun0+v_y0_yup*(m_yup-m_sun) )/(m_sun+m_yup)
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsun_merc <= r_sun+r_merc:
            Vx_sun0=(2*m_merc*v_y0_merc+v_x_sun0*(m_sun-m_merc) )/(m_sun+m_merc)
            V_y0_merc=(2*m_sun*v_x_sun0+v_y0_merc*(m_merc-m_sun) )/(m_sun+m_merc)
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsun_earth <= r_sun+r_earth:
            V_x_sun0=(2*m_earth*v_y0_earth+v_x_sun0*(m_sun-m_earth) )/(m_sun+m_earth)
            V_y0_earth=(2*m_sun*v_x_sun0+v_y0_earth*(m_earth-m_sun) )/(m_sun+m_earth)
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsun_uran <= r_sun+r_uran:
            V_x_sun0=(2*m_uran*v_y0_uran+v_x_sun0*(m_sun-m_uran) )/(m_sun+m_uran)
            V_y0_uran=(2*m_sun*v_x_sun0+v_y0_uran*(m_uran-m_sun) )/(m_sun+m_uran)
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsun_neptun <= r_sun+r_neptun:
            V_x_sun0=(2*m_neptun*v_y0_neptun+v_x_sun0*(m_sun-m_neptun) )/(m_sun+m_neptun)
            V_y0_neptun=(2*m_sun*v_x_sun0+v_y0_neptun*(m_neptun-m_sun) )/(m_sun+m_neptun)
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsun_mars2 <=  r_sun+r_mars:
            V_x_sun0=(2*m_mars*v_y0_mars2+v_x_sun0*(m_sun-m_mars) )/(m_sun+m_mars)
            V_y0_mars2=(2*m_sun*v_x_sun0+v_y0_mars2*(m_mars-m_sun) )/(m_sun+m_mars)
            V_x_sun20= v_x_sun20
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars= v_y0_mars
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsun_ven2 <= r_sun+r_ven:
            V_x_sun0=(2*m_ven*v_y0_ven2+v_x_sun0*(m_sun-m_ven) )/(m_sun+m_ven)
            V_y0_ven2=(2*m_sun*v_x_sun0+v_y0_ven2*(m_ven-m_sun) )/(m_sun+m_ven)
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven= v_y0_ven
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsun_saturn2 <= r_sun+r_saturn:
            V_x_sun0=(2*m_saturn*v_y0_saturn2+v_x_sun0*(m_sun-m_saturn) )/(m_sun+m_saturn)
            V_y0_saturn2=(2*m_sun*v_x_sun0+v_y0_saturn2*(m_saturn-m_sun) )/(m_sun+m_saturn)
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn= v_y0_saturn
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsun_yup2 <= r_sun+r_yup:
            V_x_sun0=(2*m_yup*v_y0_yup2+v_x_sun0*(m_sun-m_yup) )/(m_sun+m_yup)
            V_y0_yup2=(2*m_sun*v_x_sun0+v_y0_yup2*(m_yup-m_sun) )/(m_sun+m_yup)
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsun_merc2 <= r_sun+r_merc:
            V_x_sun0=(2*m_merc*v_y0_merc2+v_x_sun0*(m_sun-m_merc) )/(m_sun+m_merc)
            V_y0_merc2=(2*m_sun*v_x_sun0+v_y0_merc2*(m_merc-m_sun) )/(m_sun+m_merc)
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc= v_y0_merc
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsun_earth2 <= r_sun+r_earth:
            V_x_sun0=(2*m_earth*v_y0_earth2+v_x_sun0*(m_sun-m_earth) )/(m_sun+m_earth)
            V_y0_earth2=(2*m_sun*v_x_sun0+v_y0_earth2*(m_earth-m_sun) )/(m_sun+m_earth)
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth =v_y0_earth
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsun_uran2 <= r_sun+r_uran:
            V_x_sun0=(2*m_uran*v_y0_uran2+v_x_sun0*(m_sun-m_uran) )/(m_sun+m_uran)
            V_y0_uran2=(2*m_sun*v_x_sun0+v_y0_uran2*(m_uran-m_sun) )/(m_sun+m_uran)
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran =v_y0_uran
            V_y0_neptun2= v_y0_neptun2
        elif rsun_neptun2 <= r_sun+r_neptun:
            V_x_sun0=(2*m_neptun*v_y0_neptun2+v_x_sun0*(m_sun-m_neptun) )/(m_sun+m_neptun)
            V_y0_neptun2=(2*m_sun*v_x_sun0+v_y0_neptun2*(m_neptun-m_sun) )/(m_sun+m_neptun)
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun= v_y0_neptun
        elif rmars_sun2 <= r_mars+r_sun:
            V_y0_mars=(2*m_sun*v_x_sun20+v_y0_mars*(m_mars-m_sun) )/(m_mars+m_sun)
            V_x_sun20=(2*m_mars*v_y0_mars+v_x_sun20*(m_sun -m_mars) )/(m_mars+m_sun)
            V_x_sun0= v_x_sun0
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
    
        elif rmars_ven <= r_mars+r_ven:
            V_y0_mars=(2*m_ven*v_y0_ven+v_y0_mars*(m_mars-m_ven) )/(m_mars+m_ven)
            V_y0_ven=(2*m_mars*v_y0_mars+v_y0_ven*(m_ven-m_mars) )/(m_mars+m_ven)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
    
        elif rmars_saturn <= r_mars+r_saturn:
            V_y0_mars=(2*m_saturn*v_y0_saturn+v_y0_mars*(m_mars-m_saturn) )/(m_mars+m_saturn)
            V_y0_saturn=(2*m_mars*v_y0_mars+v_y0_saturn*(m_saturn-m_mars) )/(m_mars+m_saturn)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_ven= v_y0_ven
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
    
        elif rmars_yup <= r_mars+r_yup:
            Vx_mars0=(2*m_yup*v_y0_yup+v_y0_mars*(m_mars-m_yup) )/(m_mars+m_yup)
            V_y0_yup=(2*m_mars*v_y0_mars+v_y0_yup*(m_yup-m_mars) )/(m_mars+m_yup)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
    
        elif rmars_merc <= r_mars+r_merc:
            Vx_mars0=(2*m_merc*v_y0_merc+v_y0_mars*(m_mars-m_merc) )/(m_mars+m_merc)
            V_y0_merc=(2*m_mars*v_y0_mars+v_y0_merc*(m_merc-m_mars) )/(m_mars+m_merc)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
    
        elif rmars_earth <= r_mars+r_earth:
            V_y0_mars=(2*m_earth*v_y0_earth+v_y0_mars*(m_mars-m_earth) )/(m_mars+m_earth)
            V_y0_earth=(2*m_mars*v_y0_mars+v_y0_earth*(m_earth-m_mars) )/(m_mars+m_earth)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
    
        elif rmars_uran <= r_mars+r_uran:
            V_y0_mars=(2*m_uran*v_y0_uran+v_y0_mars*(m_mars-m_uran) )/(m_mars+m_uran)
            V_y0_uran=(2*m_mars*v_y0_mars+v_y0_uran*(m_uran-m_mars) )/(m_mars+m_uran)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
    
        elif rmars_neptun <= r_mars+r_neptun:
            V_y0_mars=(2*m_neptun*v_y0_neptun+v_y0_mars*(m_mars-m_neptun) )/(m_mars+m_neptun)
            V_y0_neptun=(2*m_mars*v_y0_mars+v_y0_neptun*(m_neptun-m_mars) )/(m_mars+m_neptun)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmars_mars2 <=  r_mars+r_mars:
            V_y0_mars=(2*m_mars*v_y0_mars2+v_y0_mars*(m_mars-m_mars) )/(m_mars+m_mars)
            V_y0_mars2=(2*m_mars*v_y0_mars+v_y0_mars2*(m_mars-m_mars) )/(m_mars+m_mars)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmars_ven2 <= r_mars+r_ven:
            V_y0_mars=(2*m_ven*v_y0_ven2+v_y0_mars*(m_mars-m_ven) )/(m_mars+m_ven)
            V_y0_ven2=(2*m_mars*v_y0_mars+v_y0_ven2*(m_ven-m_mars) )/(m_mars+m_ven)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmars_saturn2 <= r_mars+r_saturn:
            V_y0_mars=(2*m_saturn*v_y0_saturn2+v_y0_mars*(m_mars-m_saturn) )/(m_mars+m_saturn)
            V_y0_saturn2=(2*m_mars*v_y0_mars+v_y0_saturn2*(m_saturn-m_mars) )/(m_mars+m_saturn)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmars_yup2 <= r_mars+r_yup:
            V_y0_mars=(2*m_yup*v_y0_yup2+v_y0_mars*(m_mars-m_yup) )/(m_mars+m_yup)
            V_y0_yup2=(2*m_mars*v_y0_mars+v_y0_yup2*(m_yup-m_mars) )/(m_mars+m_yup)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmars_merc2 <= r_mars+r_merc:
            V_y0_mars=(2*m_merc*v_y0_merc2+v_y0_mars*(m_mars-m_merc) )/(m_mars+m_merc)
            V_y0_merc2=(2*m_mars*v_y0_mars+v_y0_merc2*(m_merc-m_mars) )/(m_mars+m_merc)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmars_earth2 <= r_mars+r_earth:
            V_y0_mars=(2*m_earth*v_y0_earth2+v_y0_mars*(m_mars-m_earth) )/(m_mars+m_earth)
            V_y0_earth2=(2*m_mars*v_y0_mars+v_y0_earth2*(m_earth-m_mars) )/(m_mars+m_earth)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmars_uran2 <= r_mars+r_uran:
            V_y0_mars=(2*m_uran*v_y0_uran2+v_y0_mars*(m_mars-m_uran) )/(m_mars+m_uran)
            V_y0_uran2=(2*m_mars*v_y0_mars+v_y0_uran2*(m_uran-m_mars) )/(m_mars+m_uran)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_neptun2= v_y0_neptun2
        elif rmars_neptun2 <= r_mars+r_neptun:
            V_y0_mars=(2*m_neptun*v_y0_neptun2+v_y0_mars*(m_mars-m_neptun) )/(m_mars+m_neptun)
            V_y0_neptun2=(2*m_mars*v_y0_mars+v_y0_neptun2*(m_neptun-m_mars) )/(m_mars+m_neptun)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
    
        elif rven_sun2 <= r_ven+r_sun:
            V_y0_ven=(2*m_sun*v_x_sun20+v_y0_ven*(m_ven-m_sun) )/(m_ven+m_sun)
            V_x_sun20=(2*m_ven*v_y0_ven+v_x_sun20*(m_sun -m_ven) )/(m_ven+m_sun)
            V_x_sun0= v_x_sun0
            V_y0_mars= v_y0_mars
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rven_saturn <= r_ven+r_saturn:
            V_y0_ven=(2*m_saturn*v_y0_saturn+v_y0_ven*(m_ven-m_saturn) )/(m_ven+m_saturn)
            V_y0_saturn=(2*m_ven*v_y0_ven+v_y0_saturn*(m_saturn-m_ven) )/(m_ven+m_saturn)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rven_yup <= r_ven+r_yup:
            Vx_ven0=(2*m_yup*v_y0_yup+v_y0_ven*(m_ven-m_yup) )/(m_ven+m_yup)
            V_y0_yup=(2*m_ven*v_y0_ven+v_y0_yup*(m_yup-m_ven) )/(m_ven+m_yup)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_saturn= v_y0_saturn
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rven_merc <= r_ven+r_merc:
            Vx_ven0=(2*m_merc*v_y0_merc+v_y0_ven*(m_ven-m_merc) )/(m_ven+m_merc)
            V_y0_merc=(2*m_ven*v_y0_ven+v_y0_merc*(m_merc-m_ven) )/(m_ven+m_merc)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rven_earth <= r_ven+r_earth:
            V_y0_ven=(2*m_earth*v_y0_earth+v_y0_ven*(m_ven-m_earth) )/(m_ven+m_earth)
            V_y0_earth=(2*m_ven*v_y0_ven+v_y0_earth*(m_earth-m_ven) )/(m_ven+m_earth)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rven_uran <= r_ven+r_uran:
            V_y0_ven=(2*m_uran*v_y0_uran+v_y0_ven*(m_ven-m_uran) )/(m_ven+m_uran)
            V_y0_uran=(2*m_ven*v_y0_ven+v_y0_uran*(m_uran-m_ven) )/(m_ven+m_uran)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rven_neptun <= r_ven+r_neptun:
            V_y0_ven=(2*m_neptun*v_y0_neptun+v_y0_ven*(m_ven-m_neptun) )/(m_ven+m_neptun)
            V_y0_neptun=(2*m_ven*v_y0_ven+v_y0_neptun*(m_neptun-m_ven) )/(m_ven+m_neptun)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rven_mars2 <=  r_ven+r_mars:
            V_y0_ven=(2*m_mars *v_y0_mars2+v_y0_ven*(m_ven-m_mars) )/(m_ven+m_mars)
            V_y0_mars2=(2*m_ven*v_y0_ven+v_y0_mars2*(m_mars -m_ven) )/(m_ven+m_mars)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rven_ven2 <= r_ven+r_ven:
            V_y0_ven=(2*m_ven*v_y0_ven2+v_y0_ven*(m_ven-m_ven) )/(m_ven+m_ven)
            V_y0_ven2=(2*m_ven*v_y0_ven+v_y0_ven2*(m_ven-m_ven) )/(m_ven+m_ven)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rven_saturn2 <= r_ven+r_saturn:
            V_y0_ven=(2*m_saturn*v_y0_saturn2+v_y0_ven*(m_ven-m_saturn) )/(m_ven+m_saturn)
            V_y0_saturn2=(2*m_ven*v_y0_ven+v_y0_saturn2*(m_saturn-m_ven) )/(m_ven+m_saturn)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rven_yup2 <= r_ven+r_yup:
            V_y0_ven=(2*m_yup*v_y0_yup2+v_y0_ven*(m_ven-m_yup) )/(m_ven+m_yup)
            V_y0_yup2=(2*m_ven*v_y0_ven+v_y0_yup2*(m_yup-m_ven) )/(m_ven+m_yup)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rven_merc2 <= r_ven+r_merc:
            V_y0_ven=(2*m_merc*v_y0_merc2+v_y0_ven*(m_ven-m_merc) )/(m_ven+m_merc)
            V_y0_merc2=(2*m_ven*v_y0_ven+v_y0_merc2*(m_merc-m_ven) )/(m_ven+m_merc)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rven_earth2 <= r_ven+r_earth:
            V_y0_ven=(2*m_earth*v_y0_earth2+v_y0_ven*(m_ven-m_earth) )/(m_ven+m_earth)
            V_y0_earth2=(2*m_ven*v_y0_ven+v_y0_earth2*(m_earth-m_ven) )/(m_ven+m_earth)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rven_uran2 <= r_ven+r_uran:
            V_y0_ven=(2*m_uran*v_y0_uran2+v_y0_ven*(m_ven-m_uran) )/(m_ven+m_uran)
            V_y0_uran2=(2*m_ven*v_y0_ven+v_y0_uran2*(m_uran-m_ven) )/(m_ven+m_uran)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_neptun2= v_y0_neptun2
        elif rven_neptun2 <= r_ven+r_neptun:
            V_y0_ven=(2*m_neptun*v_y0_neptun2+v_y0_ven*(m_ven-m_neptun) )/(m_ven+m_neptun)
            V_y0_neptun2=(2*m_ven*v_y0_ven+v_y0_neptun2*(m_neptun-m_ven) )/(m_ven+m_neptun)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
        elif rsaturn_sun2 <= r_saturn+r_sun:
            V_y0_saturn=(2*m_sun*v_x_sun20+v_y0_saturn*(m_saturn-m_sun) )/(m_saturn+m_sun)
            V_x_sun20=(2*m_saturn*v_y0_saturn+v_x_sun20*(m_sun -m_saturn) )/(m_saturn+m_sun)
            V_x_sun0= v_x_sun0
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsaturn_yup <= r_saturn+r_yup:
            Vx_saturn0=(2*m_yup*v_y0_yup+v_y0_saturn*(m_saturn-m_yup) )/(m_saturn+m_yup)
            V_y0_yup=(2*m_saturn*v_y0_saturn+v_y0_yup*(m_yup-m_saturn) )/(m_saturn+m_yup)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsaturn_merc <= r_saturn+r_merc:
            Vx_saturn0=(2*m_merc*v_y0_merc+v_y0_saturn*(m_saturn-m_merc) )/(m_saturn+m_merc)
            V_y0_merc=(2*m_saturn*v_y0_saturn+v_y0_merc*(m_merc-m_saturn) )/(m_saturn+m_merc)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_yup= v_y0_yup
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsaturn_earth <= r_saturn+r_earth:
            V_y0_saturn=(2*m_earth*v_y0_earth+v_y0_saturn*(m_saturn-m_earth) )/(m_saturn+m_earth)
            V_y0_earth=(2*m_saturn*v_y0_saturn+v_y0_earth*(m_earth-m_saturn) )/(m_saturn+m_earth)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsaturn_uran <= r_saturn+r_uran:
            V_y0_saturn=(2*m_uran*v_y0_uran+v_y0_saturn*(m_saturn-m_uran) )/(m_saturn+m_uran)
            V_y0_uran=(2*m_saturn*v_y0_saturn+v_y0_uran*(m_uran-m_saturn) )/(m_saturn+m_uran)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsaturn_neptun <= r_saturn+r_neptun:
            V_y0_saturn=(2*m_neptun*v_y0_neptun+v_y0_saturn*(m_saturn-m_neptun) )/(m_saturn+m_neptun)
            V_y0_neptun=(2*m_saturn*v_y0_saturn+v_y0_neptun*(m_neptun-m_saturn) )/(m_saturn+m_neptun)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsaturn_mars2 <=  r_saturn+r_mars:
            V_y0_saturn=(2*m_mars *v_y0_mars2+v_y0_saturn*(m_saturn-m_mars) )/(m_saturn+m_mars)
            V_y0_mars2=(2*m_saturn*v_y0_saturn+v_y0_mars2*(m_mars-m_saturn) )/(m_saturn+m_mars)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsaturn_ven2 <= r_saturn+r_ven:
            V_y0_saturn=(2*m_ven*v_y0_ven2+v_y0_saturn*(m_saturn-m_ven) )/(m_saturn+m_ven)
            V_y0_ven2=(2*m_saturn*v_y0_saturn+v_y0_ven2*(m_ven-m_saturn) )/(m_saturn+m_ven)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsaturn_saturn2 <= r_saturn+r_saturn:
            V_y0_saturn=(2*m_saturn*v_y0_saturn2+v_y0_saturn*(m_saturn-m_saturn) )/(m_saturn+m_saturn)
            V_y0_saturn2=(2*m_saturn*v_y0_saturn+v_y0_saturn2*(m_saturn-m_saturn) )/(m_saturn+m_saturn)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsaturn_yup2 <= r_saturn+r_yup:
            V_y0_saturn=(2*m_yup*v_y0_yup2+v_y0_saturn*(m_saturn-m_yup) )/(m_saturn+m_yup)
            V_y0_yup2=(2*m_saturn*v_y0_saturn+v_y0_yup2*(m_yup-m_saturn) )/(m_saturn+m_yup)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsaturn_merc2 <= r_saturn+r_merc:
            V_y0_saturn=(2*m_merc*v_y0_merc2+v_y0_saturn*(m_saturn-m_merc) )/(m_saturn+m_merc)
            V_y0_merc2=(2*m_saturn*v_y0_saturn+v_y0_merc2*(m_merc-m_saturn) )/(m_saturn+m_merc)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsaturn_earth2 <= r_saturn+r_earth:
            V_y0_saturn=(2*m_earth*v_y0_earth2+v_y0_saturn*(m_saturn-m_earth) )/(m_saturn+m_earth)
            V_y0_earth2=(2*m_saturn*v_y0_saturn+v_y0_earth2*(m_earth-m_saturn) )/(m_saturn+m_earth)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsaturn_uran2 <= r_saturn+r_uran:
            V_y0_saturn=(2*m_uran*v_y0_uran2+v_y0_saturn*(m_saturn-m_uran) )/(m_saturn+m_uran)
            V_y0_uran2=(2*m_saturn*v_y0_saturn+v_y0_uran2*(m_uran-m_saturn) )/(m_saturn+m_uran)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_neptun2= v_y0_neptun2
        elif rsaturn_neptun2 <= r_saturn+r_neptun:
            V_y0_saturn=(2*m_neptun*v_y0_neptun2+v_y0_saturn*(m_saturn-m_neptun) )/(m_saturn+m_neptun)
            V_y0_neptun2=(2*m_saturn*v_y0_saturn+v_y0_neptun2*(m_neptun-m_saturn) )/(m_saturn+m_neptun)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
        elif ryup_sun2 <= r_yup+r_sun:
            V_y0_yup=(2*m_sun*v_x_sun20+v_y0_yup*(m_yup-m_sun) )/(m_yup+m_sun)
            V_x_sun20=(2*m_yup*v_y0_yup+v_x_sun20*(m_sun -m_yup) )/(m_yup+m_sun)
            V_x_sun0= v_x_sun0
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif ryup_merc <= r_yup+r_merc:
            Vx_yup0=(2*m_merc*v_y0_merc+v_y0_yup*(m_yup-m_merc) )/(m_yup+m_merc)
            V_y0_merc=(2*m_yup*v_y0_yup+v_y0_merc*(m_merc-m_yup) )/(m_yup+m_merc)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif ryup_earth <= r_yup+r_earth:
            V_y0_yup=(2*m_earth*v_y0_earth+v_y0_yup*(m_yup-m_earth) )/(m_yup+m_earth)
            V_y0_earth=(2*m_yup*v_y0_yup+v_y0_earth*(m_earth-m_yup) )/(m_yup+m_earth)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_merc=  v_y0_merc
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif ryup_uran <= r_yup+r_uran:
            V_y0_yup=(2*m_uran*v_y0_uran+v_y0_yup*(m_yup-m_uran) )/(m_yup+m_uran)
            V_y0_uran=(2*m_yup*v_y0_yup+v_y0_uran*(m_uran-m_yup) )/(m_yup+m_uran)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif ryup_neptun <= r_yup+r_neptun:
            V_y0_yup=(2*m_neptun*v_y0_neptun+v_y0_yup*(m_yup-m_neptun) )/(m_yup+m_neptun)
            V_y0_neptun=(2*m_yup*v_y0_yup+v_y0_neptun*(m_neptun-m_yup) )/(m_yup+m_neptun)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif ryup_mars2 <=  r_yup+r_mars:
            V_y0_yup=(2*m_mars *v_y0_mars2+v_y0_yup*(m_yup-m_mars) )/(m_yup+m_mars)
            V_y0_mars2=(2*m_yup*v_y0_yup+v_y0_mars2*(m_mars-m_yup) )/(m_yup+m_mars)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif ryup_ven2 <= r_yup+r_ven:
            V_y0_yup=(2*m_ven*v_y0_ven2+v_y0_yup*(m_yup-m_ven) )/(m_yup+m_ven)
            V_y0_ven2=(2*m_yup*v_y0_yup+v_y0_ven2*(m_ven-m_yup) )/(m_yup+m_ven)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif ryup_saturn2 <= r_yup+r_saturn:
            V_y0_yup= (2*m_saturn *v_y0_saturn2+v_y0_yup*(m_yup-m_saturn) )/(m_yup+m_saturn)
            V_y0_saturn2= (2*m_yup*v_y0_yup+v_y0_saturn2*(m_saturn-m_yup) )/(m_yup+m_saturn)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif ryup_yup2 <= r_yup+r_yup:
            V_y0_yup=(2*m_yup*v_y0_yup2+v_y0_yup*(m_yup-m_yup) )/(m_yup+m_yup)
            V_y0_yup2=(2*m_yup*v_y0_yup+v_y0_yup2*(m_yup-m_yup) )/(m_yup+m_yup)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif ryup_merc2 <= r_yup+r_merc:
            V_y0_yup=(2*m_merc*v_y0_merc2+v_y0_yup*(m_yup-m_merc) )/(m_yup+m_merc)
            V_y0_merc2=(2*m_yup*v_y0_yup+v_y0_merc2*(m_merc-m_yup) )/(m_yup+m_merc)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif ryup_earth2 <= r_yup+r_earth:
            V_y0_yup=(2*m_earth*v_y0_earth2+v_y0_yup*(m_yup-m_earth) )/(m_yup+m_earth)
            V_y0_earth2=(2*m_yup*v_y0_yup+v_y0_earth2*(m_earth-m_yup) )/(m_yup+m_earth)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif ryup_uran2 <= r_yup+r_uran:
            V_y0_yup=(2*m_uran*v_y0_uran2+v_y0_yup*(m_yup-m_uran) )/(m_yup+m_uran)
            V_y0_uran2=(2*m_yup*v_y0_yup+v_y0_uran2*(m_uran-m_yup) )/(m_yup+m_uran)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_neptun2= v_y0_neptun2
        elif ryup_neptun2 <= r_yup+r_neptun:
            V_y0_yup=(2*m_neptun*v_y0_neptun2+v_y0_yup*(m_yup-m_neptun) )/(m_yup+m_neptun)
            V_y0_neptun2=(2*m_yup*v_y0_yup+v_y0_neptun2*(m_neptun-m_yup) )/(m_yup+m_neptun)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
        elif rmerc_sun2 <= r_merc+r_sun:
            V_y0_merc=(2*m_sun*v_x_sun20+v_y0_merc*(m_merc-m_sun) )/(m_merc+m_sun)
            V_x_sun20=(2*m_merc*v_y0_merc+v_x_sun20*(m_sun -m_merc) )/(m_merc+m_sun)
            V_x_sun0= v_x_sun0
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmerc_earth <= r_merc+r_earth:
            V_y0_merc=(2*m_earth*v_y0_earth+v_y0_merc*(m_merc-m_earth) )/(m_merc+m_earth)
            V_y0_earth=(2*m_merc*v_y0_merc+v_y0_earth*(m_earth-m_merc) )/(m_merc+m_earth)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmerc_uran <= r_merc+r_uran:
            V_y0_merc=(2*m_uran*v_y0_uran+v_y0_merc*(m_merc-m_uran) )/(m_merc+m_uran)
            V_y0_uran=(2*m_merc*v_y0_merc+v_y0_uran*(m_uran-m_merc) )/(m_merc+m_uran)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_earth =v_y0_earth
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmerc_neptun <= r_merc+r_neptun:
            V_y0_merc=(2*m_neptun*v_y0_neptun+v_y0_merc*(m_merc-m_neptun) )/(m_merc+m_neptun)
            V_y0_neptun=(2*m_merc*v_y0_merc+v_y0_neptun*(m_neptun-m_merc) )/(m_merc+m_neptun)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmerc_mars2 <=  r_merc+r_mars:
            V_y0_merc=(2*m_mars *v_y0_mars2+v_y0_merc*(m_merc-m_mars) )/(m_merc+m_mars)
            V_y0_mars2=(2*m_merc*v_y0_merc+v_y0_mars2*(m_mars-m_merc) )/(m_merc+m_mars)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmerc_ven2 <= r_merc+r_ven:
            V_y0_merc=(2*m_ven*v_y0_ven2+v_y0_merc*(m_merc-m_ven) )/(m_merc+m_ven)
            V_y0_ven2=(2*m_merc*v_y0_merc+v_y0_ven2*(m_ven-m_merc) )/(m_merc+m_ven)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmerc_saturn2 <= r_merc+r_saturn:
            V_y0_merc= (2*m_saturn *v_y0_saturn2+v_y0_merc*(m_merc-m_saturn) )/(m_merc+m_saturn)
            V_y0_saturn2= (2*m_merc*v_y0_merc+v_y0_saturn2*(m_saturn -m_merc) )/(m_merc+m_saturn)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmerc_yup2 <= r_merc+r_merc:
            V_y0_merc=(2*m_yup*v_y0_yup2+v_y0_merc*(m_merc-m_yup) )/(m_merc+m_yup)
            V_y0_yup2=(2*m_merc*v_y0_merc+v_y0_yup2*(m_yup -m_merc) )/(m_merc+m_yup)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmerc_merc2 <= r_merc+r_merc:
            V_y0_merc=(2*m_merc*v_y0_merc2+v_y0_merc*(m_merc-m_merc) )/(m_merc+m_merc)
            V_y0_merc2=(2*m_merc*v_y0_merc+v_y0_merc2*(m_merc-m_merc) )/(m_merc+m_merc)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmerc_earth2 <= r_merc+r_earth:
            V_y0_merc=(2*m_earth*v_y0_earth2+v_y0_merc*(m_merc-m_earth) )/(m_merc+m_earth)
            V_y0_earth2=(2*m_merc*v_y0_merc+v_y0_earth2*(m_earth-m_merc) )/(m_merc+m_earth)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmerc_uran2 <= r_merc+r_uran:
            V_y0_merc=(2*m_uran*v_y0_uran2+v_y0_merc*(m_merc-m_uran) )/(m_merc+m_uran)
            V_y0_uran2=(2*m_merc*v_y0_merc+v_y0_uran2*(m_uran-m_merc) )/(m_merc+m_uran)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_neptun2= v_y0_neptun2
        elif rmerc_neptun2 <= r_merc+r_neptun:
            V_y0_merc=(2*m_neptun*v_y0_neptun2+v_y0_merc*(m_merc-m_neptun) )/(m_merc+m_neptun)
            V_y0_neptun2=(2*m_merc*v_y0_merc+v_y0_neptun2*(m_neptun-m_merc) )/(m_merc+m_neptun)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
        elif rearth_sun2 <= r_earth+r_sun:
            V_y0_earth=(2*m_sun*v_x_sun20+v_y0_earth*(m_earth-m_sun) )/(m_earth+m_sun)
            V_x_sun20=(2*m_earth*v_y0_earth+v_x_sun20*(m_sun -m_earth) )/(m_earth+m_sun)
            V_x_sun0= v_x_sun0
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rearth_uran <= r_earth+r_uran:
            V_y0_earth=(2*m_uran*v_y0_uran+v_y0_earth*(m_earth-m_uran) )/(m_earth+m_uran)
            V_y0_uran=(2*m_earth*v_y0_earth+v_y0_uran*(m_uran-m_earth) )/(m_earth+m_uran)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rearth_neptun <= r_earth+r_neptun:
            V_y0_earth=(2*m_neptun*v_y0_neptun+v_y0_earth*(m_earth-m_neptun) )/(m_earth+m_neptun)
            V_y0_neptun=(2*m_earth*v_y0_earth+v_y0_neptun*(m_neptun-m_earth) )/(m_earth+m_neptun)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_uran =v_y0_uran
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rearth_mars2 <=  r_earth+r_mars:
            V_y0_earth=(2*m_mars *v_y0_mars2+v_y0_earth*(m_earth-m_mars) )/(m_earth+m_mars)
            V_y0_mars2=(2*m_earth*v_y0_earth+v_y0_mars2*(m_mars-m_earth) )/(m_earth+m_mars)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rearth_ven2 <= r_earth+r_ven:
            V_y0_earth=(2*m_ven*v_y0_ven2+v_y0_earth*(m_earth-m_ven) )/(m_earth+m_ven)
            V_y0_ven2=(2*m_earth*v_y0_earth+v_y0_ven2*(m_ven-m_earth) )/(m_earth+m_ven)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rearth_saturn2 <= r_earth+r_saturn:
            V_y0_earth= (2*m_saturn *v_y0_saturn2+v_y0_earth*(m_earth-m_saturn) )/(m_earth+m_saturn)
            V_y0_saturn2= (2*m_earth*v_y0_earth+v_y0_saturn2*(m_saturn -m_earth) )/(m_earth+m_saturn)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rearth_yup2 <= r_earth+r_earth:
            V_y0_earth=(2*m_yup*v_y0_yup2+v_y0_earth*(m_earth-m_yup) )/(m_earth+m_yup)
            V_y0_yup2=(2*m_earth*v_y0_earth+v_y0_yup2*(m_yup -m_earth) )/(m_earth+m_yup)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rearth_merc2 <= r_earth+r_earth:
            V_y0_earth=(2*m_merc *v_y0_merc2+v_y0_earth*(m_earth-m_merc) )/(m_earth+m_merc)
            V_y0_merc2=(2*m_earth*v_y0_earth+v_y0_merc2*(m_merc -m_earth) )/(m_earth+m_merc)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rearth_earth2 <= r_earth+r_earth:
            V_y0_earth=(2*m_earth*v_y0_earth2+v_y0_earth*(m_earth-m_earth) )/(m_earth+m_earth)
            V_y0_earth2=(2*m_earth*v_y0_earth+v_y0_earth2*(m_earth-m_earth) )/(m_earth+m_earth)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_neptun2= v_y0_neptun2
        elif rearth_uran2 <= r_earth+r_uran:
            V_y0_earth=(2*m_uran*v_y0_uran2+v_y0_earth*(m_earth-m_uran) )/(m_earth+m_uran)
            V_y0_uran2=(2*m_earth*v_y0_earth+v_y0_uran2*(m_uran-m_earth) )/(m_earth+m_uran)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_neptun2= v_y0_neptun2
        elif rearth_neptun2 <= r_earth+r_neptun:
            V_y0_earth=(2*m_neptun*v_y0_neptun2+v_y0_earth*(m_earth-m_neptun) )/(m_earth+m_neptun)
            V_y0_neptun2=(2*m_earth*v_y0_earth+v_y0_neptun2*(m_neptun-m_earth) )/(m_earth+m_neptun)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
        elif ruran_sun2 <= r_uran+r_sun:
            V_y0_uran=(2*m_sun*v_x_sun20+v_y0_uran*(m_uran-m_sun) )/(m_uran+m_sun)
            V_x_sun20=(2*m_uran*v_y0_uran+v_x_sun20*(m_sun -m_uran) )/(m_uran+m_sun)
            V_x_sun0= v_x_sun0
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif ruran_neptun <= r_uran+r_neptun:
            V_y0_uran=(2*m_neptun*v_y0_neptun+v_y0_uran*(m_uran-m_neptun) )/(m_uran+m_neptun)
            V_y0_neptun=(2*m_uran*v_y0_uran+v_y0_neptun*(m_neptun-m_uran) )/(m_uran+m_neptun)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif ruran_mars2 <=  r_uran+r_mars:
            V_y0_uran=(2*m_mars *v_y0_mars2+v_y0_uran*(m_uran-m_mars) )/(m_uran+m_mars)
            V_y0_mars2=(2*m_uran*v_y0_uran+v_y0_mars2*(m_mars-m_uran) )/(m_uran+m_mars)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_neptun= v_y0_neptun
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif ruran_ven2 <= r_uran+r_ven:
            V_y0_uran=(2*m_ven*v_y0_ven2+v_y0_uran*(m_uran-m_ven) )/(m_uran+m_ven)
            V_y0_ven2=(2*m_uran*v_y0_uran+v_y0_ven2*(m_ven-m_uran) )/(m_uran+m_ven)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif ruran_saturn2 <= r_uran+r_saturn:
            V_y0_uran= (2*m_saturn *v_y0_saturn2+v_y0_uran*(m_uran-m_saturn) )/(m_uran+m_saturn)
            V_y0_saturn2= (2*m_uran*v_y0_uran+v_y0_saturn2*(m_saturn -m_uran) )/(m_uran+m_saturn)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif ruran_yup2 <= r_uran+r_uran:
            V_y0_uran=(2*m_yup*v_y0_yup2+v_y0_uran*(m_uran-m_yup) )/(m_uran+m_yup)
            V_y0_yup2=(2*m_uran*v_y0_uran+v_y0_yup2*(m_yup -m_uran) )/(m_uran+m_yup)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif ruran_merc2 <= r_uran+r_uran:
            V_y0_uran=(2*m_merc *v_y0_merc2+v_y0_uran*(m_uran-m_merc) )/(m_uran+m_merc)
            V_y0_merc2=(2*m_uran*v_y0_uran+v_y0_merc2*(m_merc -m_uran) )/(m_uran+m_merc)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif ruran_earth2 <= r_uran+r_earth:
            V_y0_uran=(2*m_earth *v_y0_earth2+v_y0_uran*(m_uran-m_earth) )/(m_uran+m_earth)
            V_y0_earth2=(2*m_uran*v_y0_uran+v_y0_earth2*(m_earth -m_uran) )/(m_uran+m_earth)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
    
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif ruran_uran2 <= r_uran+r_uran:
            V_y0_uran=(2*m_uran*v_y0_uran2+v_y0_uran*(m_uran-m_uran) )/(m_uran+m_uran)
            V_y0_uran2=(2*m_uran*v_y0_uran+v_y0_uran2*(m_uran-m_uran) )/(m_uran+m_uran)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_neptun2= v_y0_neptun2
        elif ruran_neptun2 <= r_uran+r_neptun:
            V_y0_uran=(2*m_neptun*v_y0_neptun2+v_y0_uran*(m_uran-m_neptun) )/(m_uran+m_neptun)
            V_y0_neptun2=(2*m_uran*v_y0_uran+v_y0_neptun2*(m_neptun-m_uran) )/(m_uran+m_neptun)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
        elif rneptun_sun2 <= r_neptun+r_sun:
            V_y0_neptun=(2*m_sun*v_x_sun20+v_y0_neptun*(m_neptun-m_sun) )/(m_neptun+m_sun)
            V_x_sun20=(2*m_neptun*v_y0_neptun+v_x_sun20*(m_sun -m_neptun) )/(m_neptun+m_sun)
            V_x_sun0= v_x_sun0
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rneptun_mars2 <=  r_neptun+r_mars:
            V_y0_neptun=(2*m_mars *v_y0_mars2+v_y0_neptun*(m_neptun-m_mars) )/(m_neptun+m_mars)
            V_y0_mars2=(2*m_neptun*v_y0_neptun+v_y0_mars2*(m_mars-m_neptun) )/(m_neptun+m_mars)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rneptun_ven2 <= r_neptun+r_ven:
            V_y0_neptun=(2*m_ven*v_y0_ven2+v_y0_neptun*(m_neptun-m_ven) )/(m_neptun+m_ven)
            V_y0_ven2=(2*m_neptun*v_y0_neptun+v_y0_ven2*(m_ven-m_neptun) )/(m_neptun+m_ven)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_mars2= v_y0_mars2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rneptun_saturn2 <= r_neptun+r_saturn:
            V_y0_neptun= (2*m_saturn *v_y0_saturn2+v_y0_neptun*(m_neptun-m_saturn) )/(m_neptun+m_saturn)
            V_y0_saturn2= (2*m_neptun*v_y0_neptun+v_y0_saturn2*(m_saturn -m_neptun) )/(m_neptun+m_saturn)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rneptun_yup2 <= r_neptun+r_neptun:
            V_y0_neptun=(2*m_yup*v_y0_yup2+v_y0_neptun*(m_neptun-m_yup) )/(m_neptun+m_yup)
            V_y0_yup2=(2*m_neptun*v_y0_neptun+v_y0_yup2*(m_yup -m_neptun) )/(m_neptun+m_yup)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rneptun_merc2 <= r_neptun+r_neptun:
            V_y0_neptun=(2*m_merc *v_y0_merc2+v_y0_neptun*(m_neptun-m_merc) )/(m_neptun+m_merc)
            V_y0_merc2=(2*m_neptun*v_y0_neptun+v_y0_merc2*(m_merc -m_neptun) )/(m_neptun+m_merc)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rneptun_earth2 <= r_neptun+r_earth:
            V_y0_neptun=(2*m_earth *v_y0_earth2+v_y0_neptun*(m_neptun-m_earth) )/(m_neptun+m_earth)
            V_y0_earth2=(2*m_neptun*v_y0_neptun+v_y0_earth2*(m_earth-m_neptun) )/(m_neptun+m_earth)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rneptun_uran2 <= r_neptun+r_uran:
            V_y0_neptun=(2*m_uran *v_y0_uran2+v_y0_neptun*(m_neptun-m_uran) )/(m_neptun+m_uran)
            V_y0_uran2=(2*m_neptun*v_y0_neptun+v_y0_uran2*(m_uran -m_neptun) )/(m_neptun+m_uran)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_neptun2= v_y0_neptun2
        elif rneptun_neptun2 <= r_neptun+r_neptun:
            V_y0_neptun=(2*m_neptun*v_y0_neptun2+v_y0_neptun*(m_neptun-m_neptun) )/(m_neptun+m_neptun)
            V_y0_neptun2=(2*m_neptun*v_y0_neptun+v_y0_neptun2*(m_neptun-m_neptun) )/(m_neptun+m_neptun)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
        elif rmars2_sun2 <= r_mars+r_sun:
            V_y0_mars2=(2*m_sun*v_x_sun20+v_y0_mars2*(m_mars-m_sun) )/(m_mars+m_sun)
            V_x_sun20=(2*m_mars*v_y0_mars2+v_x_sun20*(m_sun -m_mars) )/(m_mars+m_sun)
            V_x_sun0= v_x_sun0
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmars2_ven2 <= r_mars+r_ven:
            V_y0_mars2=(2*m_ven*v_y0_ven2+v_y0_mars2*(m_mars-m_ven) )/(m_mars+m_ven)
            V_y0_ven2=(2*m_mars*v_y0_mars2+v_y0_ven2*(m_ven-m_mars) )/(m_mars+m_ven)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmars2_saturn2 <= r_mars+r_saturn:
            V_y0_mars2= (2*m_saturn *v_y0_saturn2+v_y0_mars2*(m_mars-m_saturn) )/(m_mars+m_saturn)
            V_y0_saturn2= (2*m_mars*v_y0_mars2+v_y0_saturn2*(m_saturn -m_mars) )/(m_mars+m_saturn)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_ven2= v_y0_ven2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmars2_yup2 <= r_mars+r_yup:
            V_y0_mars2=(2*m_yup*v_y0_yup2+v_y0_mars2*(m_mars-m_yup) )/(m_mars+m_yup)
            V_y0_yup2=(2*m_mars*v_y0_mars2+v_y0_yup2*(m_yup -m_mars) )/(m_mars+m_yup)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmars2_merc2 <= r_mars+r_merc:
            V_y0_mars2=(2*m_merc *v_y0_merc2+v_y0_mars2*(m_mars-m_merc) )/(m_mars+m_merc)
            V_y0_merc2=(2*m_mars*v_y0_mars2+v_y0_merc2*(m_merc-m_mars) )/(m_mars+m_merc)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmars2_earth2 <= r_mars+r_earth:
            V_y0_mars2=(2*m_earth *v_y0_earth2+v_y0_mars2*(m_mars-m_earth) )/(m_mars+m_earth)
            V_y0_earth2=(2*m_mars*v_y0_mars2+v_y0_earth2*(m_earth -m_mars) )/(m_mars+m_earth)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmars2_uran2 <= r_mars+r_uran:
            V_y0_mars2=(2*m_uran *v_y0_uran2+v_y0_mars2*(m_mars-m_uran) )/(m_mars+m_uran)
            V_y0_uran2=(2*m_mars*v_y0_mars2+v_y0_uran2*(m_uran -m_mars) )/(m_mars+m_uran)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_neptun2= v_y0_neptun2
        elif rmars2_neptun2 <= r_mars+r_neptun:
            V_y0_mars2=(2*m_neptun *v_y0_neptun2+v_y0_mars2*(m_mars-m_neptun) )/(m_mars+m_neptun)
            V_y0_neptun2=(2*m_mars*v_y0_mars2+v_y0_neptun2*(m_neptun -m_mars) )/(m_mars+m_neptun)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
        elif rven2_sun2 <= r_ven+r_sun:
            V_y0_ven2=(2*m_sun*v_x_sun20+v_y0_ven2*(m_ven-m_sun) )/(m_ven+m_sun)
            V_x_sun20=(2*m_ven*v_y0_ven2+v_x_sun20*(m_sun -m_ven) )/(m_ven+m_sun)
            V_x_sun0= v_x_sun0
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rven2_saturn2 <= r_ven+r_saturn:
            V_y0_ven2= (2*m_saturn *v_y0_saturn2+v_y0_ven2*(m_ven-m_saturn) )/(m_ven+m_saturn)
            V_y0_saturn2= (2*m_ven*v_y0_ven2+v_y0_saturn2*(m_saturn -m_ven) )/(m_ven+m_saturn)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rven2_yup2 <= r_ven+r_yup:
            V_y0_ven2=(2*m_yup*v_y0_yup2+v_y0_ven2*(m_ven-m_yup) )/(m_ven+m_yup)
            V_y0_yup2=(2*m_ven*v_y0_ven2+v_y0_yup2*(m_yup -m_ven) )/(m_ven+m_yup)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_saturn2= v_y0_saturn2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rven2_merc2 <= r_ven+r_merc:
            V_y0_ven2=(2*m_merc *v_y0_merc2+v_y0_ven2*(m_ven-m_merc) )/(m_ven+m_merc)
            V_y0_merc2=(2*m_ven*v_y0_ven2+v_y0_merc2*(m_merc -m_ven) )/(m_ven+m_merc)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rven2_earth2 <= r_ven+r_earth:
            V_y0_ven2=(2*m_earth *v_y0_earth2+v_y0_ven2*(m_ven-m_earth) )/(m_ven+m_earth)
            V_y0_earth2=(2*m_ven*v_y0_ven2+v_y0_earth2*(m_earth -m_ven) )/(m_ven+m_earth)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rven2_uran2 <= r_ven+r_uran:
            V_y0_ven2=(2*m_uran *v_y0_uran2+v_y0_ven2*(m_ven-m_uran) )/(m_ven+m_uran)
            V_y0_uran2=(2*m_ven*v_y0_ven2+v_y0_uran2*(m_uran -m_ven) )/(m_ven+m_uran)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_neptun2= v_y0_neptun2
        elif rven2_neptun2 <= r_ven+r_neptun:
            V_y0_ven2=(2*m_neptun *v_y0_neptun2+v_y0_ven2*(m_ven-m_neptun) )/(m_ven+m_neptun)
            V_y0_neptun2=(2*m_ven*v_y0_ven2+v_y0_neptun2*(m_neptun -m_ven) )/(m_ven+m_neptun)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
        elif rsaturn2_sun2 <= r_saturn+r_sun:
            V_y0_saturn2=(2*m_sun*v_x_sun20+v_y0_saturn2*(m_saturn-m_sun) )/(m_saturn+m_sun)
            V_x_sun20=(2*m_saturn*v_y0_saturn2+v_x_sun20*(m_sun -m_saturn) )/(m_saturn+m_sun)
            V_x_sun0= v_x_sun0
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsaturn2_yup2 <= r_saturn+r_yup:
            V_y0_saturn2=(2*m_yup*v_y0_yup2+v_y0_saturn2*(m_saturn-m_yup) )/(m_saturn+m_yup)
            V_y0_yup2=(2*m_saturn*v_y0_saturn2+v_y0_yup2*(m_yup -m_saturn) )/(m_saturn+m_yup)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsaturn2_merc2 <= r_saturn+r_merc:
            V_y0_saturn2=(2*m_merc *v_y0_merc2+v_y0_saturn2*(m_saturn-m_merc) )/(m_saturn+m_merc)
            V_y0_merc2=(2*m_saturn*v_y0_saturn2+v_y0_merc2*(m_merc -m_saturn) )/(m_saturn+m_merc)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_yup2= v_y0_yup2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsaturn2_earth2 <= r_saturn+r_earth:
            V_y0_saturn2=(2*m_earth *v_y0_earth2+v_y0_saturn2*(m_saturn-m_earth) )/(m_saturn+m_earth)
            V_y0_earth2=(2*m_saturn*v_y0_saturn2+v_y0_earth2*(m_earth -m_saturn) )/(m_saturn+m_earth)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rsaturn2_uran2 <= r_saturn+r_uran:
            V_y0_saturn2=(2*m_uran *v_y0_uran2+v_y0_saturn2*(m_saturn-m_uran) )/(m_saturn+m_uran)
            V_y0_uran2=(2*m_saturn*v_y0_saturn2+v_y0_uran2*(m_uran -m_saturn) )/(m_saturn+m_uran)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_neptun2= v_y0_neptun2
        elif rsaturn2_neptun2 <= r_saturn+r_neptun:
            V_y0_saturn2=(2*m_neptun *v_y0_neptun2+v_y0_saturn2*(m_saturn-m_neptun) )/(m_saturn+m_neptun)
            V_y0_neptun2=(2*m_saturn*v_y0_saturn2+v_y0_neptun2*(m_neptun -m_saturn) )/(m_saturn+m_neptun)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
        elif ryup2_sun2 <= r_yup+r_sun:
            V_y0_yup2=(2*m_sun*v_x_sun20+v_y0_yup2*(m_yup-m_sun) )/(m_yup+m_sun)
            V_x_sun20=(2*m_yup*v_y0_yup2+v_x_sun20*(m_sun -m_yup) )/(m_yup+m_sun)
            V_x_sun0= v_x_sun0
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif ryup2_merc2 <= r_yup+r_merc:
            V_y0_yup2=(2*m_merc *v_y0_merc2+v_y0_yup2*(m_yup-m_merc) )/(m_yup+m_merc)
            V_y0_merc2=(2*m_yup*v_y0_yup2+v_y0_merc2*(m_merc -m_yup) )/(m_yup+m_merc)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif ryup2_earth2 <= r_yup+r_earth:
            V_y0_yup2=(2*m_earth *v_y0_earth2+v_y0_yup2*(m_yup-m_earth) )/(m_yup+m_earth)
            V_y0_earth2=(2*m_yup*v_y0_yup2+v_y0_earth2*(m_earth -m_yup) )/(m_yup+m_earth)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_merc2= v_y0_merc2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif ryup2_uran2 <= r_yup+r_uran:
            V_y0_yup2=(2*m_uran *v_y0_uran2+v_y0_yup2*(m_yup-m_uran) )/(m_yup+m_uran)
            V_y0_uran2=(2*m_yup*v_y0_yup2+v_y0_uran2*(m_uran -m_yup) )/(m_yup+m_uran)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_neptun2= v_y0_neptun2
        elif ryup2_neptun2 <= r_yup+r_neptun:
            V_y0_yup2=(2*m_neptun *v_y0_neptun2+v_y0_yup2*(m_yup-m_neptun) )/(m_yup+m_neptun)
            V_y0_neptun2=(2*m_yup*v_y0_yup2+v_y0_neptun2*(m_neptun -m_yup) )/(m_yup+m_neptun)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
        elif rmerc2_sun2 <= r_merc+r_sun:
            V_y0_merc2=(2*m_sun*v_x_sun20+v_y0_merc2*(m_merc-m_sun) )/(m_merc+m_sun)
            V_x_sun20=(2*m_merc*v_y0_merc2+v_x_sun20*(m_sun -m_merc) )/(m_merc+m_sun)
            V_x_sun0= v_x_sun0
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmerc2_earth2 <= r_merc+r_earth:
            V_y0_merc2=(2*m_earth *v_y0_earth2+v_y0_merc2*(m_merc-m_earth) )/(m_merc+m_earth)
            V_y0_earth2=(2*m_merc*v_y0_merc2+v_y0_earth2*(m_earth -m_merc) )/(m_merc+m_earth)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rmerc2_uran2 <= r_merc+r_uran:
            V_y0_merc2=(2*m_uran *v_y0_uran2+v_y0_merc2*(m_merc-m_uran) )/(m_merc+m_uran)
            V_y0_uran2=(2*m_merc*v_y0_merc2+v_y0_uran2*(m_uran -m_merc) )/(m_merc+m_uran)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_earth2 =v_y0_earth2
            V_y0_neptun2= v_y0_neptun2
        elif rmerc2_neptun2 <= r_merc+r_neptun:
            V_y0_merc2=(2*m_neptun *v_y0_neptun2+v_y0_merc2*(m_merc-m_neptun) )/(m_merc+m_neptun)
            V_y0_neptun2=(2*m_merc*v_y0_merc2+v_y0_neptun2*(m_neptun -m_merc) )/(m_merc+m_neptun)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
        elif rearth2_sun2 <= r_earth+r_sun:
            V_y0_earth2=(2*m_sun*v_x_sun20+v_y0_earth2*(m_earth-m_sun) )/(m_earth+m_sun)
            V_x_sun20=(2*m_earth*v_y0_earth2+v_x_sun20*(m_sun -m_earth) )/(m_earth+m_sun)
            V_x_sun0= v_x_sun0
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
        elif rearth2_uran2 <= r_earth+r_uran:
            V_y0_earth2=(2*m_uran *v_y0_uran2+v_y0_earth2*(m_earth-m_uran) )/(m_earth+m_uran)
            V_y0_uran2=(2*m_earth*v_y0_earth2+v_y0_uran2*(m_uran -m_earth) )/(m_earth+m_uran)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_neptun2= v_y0_neptun2
        elif rearth2_neptun2 <= r_earth+r_neptun:
            V_y0_earth2=(2*m_neptun *v_y0_neptun2+v_y0_earth2*(m_earth-m_neptun) )/(m_earth+m_neptun)
            V_y0_neptun2=(2*m_earth*v_y0_earth2+v_y0_neptun2*(m_neptun -m_earth) )/(m_earth+m_neptun)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_uran2 =v_y0_uran2
        elif ruran2_sun2 <= r_uran+r_sun:
            V_y0_uran2=(2*m_sun*v_x_sun20+v_y0_uran2*(m_uran-m_sun) )/(m_uran+m_sun)
            V_x_sun20=(2*m_uran*v_y0_uran2+v_x_sun20*(m_sun -m_uran) )/(m_uran+m_sun)
            V_x_sun0= v_x_sun0
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_neptun2= v_y0_neptun2
        elif ruran2_neptun2 <= r_uran+r_neptun:
            V_y0_uran2=(2*m_neptun *v_y0_neptun2+v_y0_uran2*(m_uran-m_neptun) )/(m_uran+m_neptun)
            V_y0_neptun2=(2*m_uran*v_y0_uran2+v_y0_neptun2*(m_neptun -m_uran) )/(m_uran+m_neptun)
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
        elif rneptun2_sun2 <= r_neptun+r_sun:
            V_y0_neptun2=(2*m_sun*v_x_sun20+v_y0_neptun2*(m_neptun-m_sun) )/(m_neptun+m_sun)
            V_x_sun20=(2*m_neptun*v_y0_neptun2+v_x_sun20*(m_sun -m_neptun) )/(m_neptun+m_sun)
            V_x_sun0= v_x_sun0
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
    
    
    
        else:
            V_x_sun0= v_x_sun0
            V_x_sun20= v_x_sun20
            V_y0_mars= v_y0_mars
            V_y0_ven= v_y0_ven
            V_y0_saturn= v_y0_saturn
            V_y0_yup= v_y0_yup
            V_y0_merc=  v_y0_merc
            V_y0_earth =v_y0_earth
            V_y0_uran =v_y0_uran
            V_y0_neptun= v_y0_neptun
            V_y0_mars2= v_y0_mars2
            V_y0_ven2= v_y0_ven2
            V_y0_saturn2= v_y0_saturn2
            V_y0_yup2= v_y0_yup2
            V_y0_merc2= v_y0_merc2
            V_y0_earth2 =v_y0_earth2
            V_y0_uran2 =v_y0_uran2
            V_y0_neptun2= v_y0_neptun2
    
    
        s0= (x_sun0, V_x_sun0, y_sun0, v_y_sun0,
            x_sun20, V_x_sun20, y_sun20, v_y_sun20,
            x0_mars, v_x0_mars, y0_mars, V_y0_mars,
            x0_ven, v_x0_ven, y0_ven, V_y0_ven,
            x0_saturn, v_x0_saturn, y0_saturn, V_y0_saturn,
            x0_yup, v_x0_yup, y0_yup, V_y0_yup,
            x0_merc, v_x0_merc, y0_merc, V_y0_merc,
            x0_earth,v_x0_earth, y0_earth, V_y0_earth,
            x0_uran, v_x0_uran, y0_uran, V_y0_uran,
            x0_neptun, v_x0_neptun,y0_neptun, V_y0_neptun,
            x0_mars2, v_x0_mars2, y0_mars2, V_y0_mars2,
            x0_ven2, v_x0_ven2, y0_ven2, V_y0_ven2,
            x0_saturn2, v_x0_saturn2,y0_saturn2, V_y0_saturn2,
            x0_yup2, v_x0_yup2, y0_yup2, V_y0_yup2,
            x0_merc2, v_x0_merc2, y0_merc2, V_y0_merc2,
            x0_earth2, v_x0_earth2, y0_earth2, V_y0_earth2,
            x0_uran2, v_x0_uran2,y0_uran2, V_y0_uran2,
            x0_neptun2, v_x0_neptun2, y0_neptun2, V_y0_neptun2)
    
    ax = fig.add_subplot()
    
    #строим решение в виде графика и анимируем
    sun, = ax.plot([], [], '*', color='y', ms=10)
    sun2, = ax.plot([], [], '*', color='y', ms=10)
    mars, = ax.plot([],[], 'o', color='orangered')
    ven, = ax.plot([], [],'o', color= 'maroon')
    saturn, = ax.plot([], [], 'o', color='wheat')
    yup, = ax.plot([],[], 'o', color='burlywood')
    merc, = ax.plot([],[], 'o', color='goldenrod')
    earth, = ax.plot([],[], 'o', color='lightseagreen')
    uran, = ax.plot([],[], 'o', color='deepskyblue')
    neptun, = ax.plot([],[], 'o', color='steelblue')
    mars2, = ax.plot([],[], 'o', color='orangered')
    ven2, = ax.plot([], [],'o', color= 'maroon')
    saturn2, = ax.plot([], [], 'o', color='wheat')
    yup2, = ax.plot([],[], 'o', color='burlywood')
    merc2, = ax.plot([],[], 'o', color='goldenrod')
    earth2, = ax.plot([],[], 'o', color='lightseagreen')
    uran2, = ax.plot([],[], 'o', color='deepskyblue')
    neptun2, = ax.plot([],[], 'o', color='steelblue')
    
    
    def update(i): #Функция подстановки координат в анимируемый объект
        sun.set_data(move_array[i, 0], move_array[i, 1])
        sun2.set_data(move_array[i, 2], move_array[i, 3])
        mars.set_data(move_array[i, 4], move_array[i, 5])
        ven.set_data(move_array[i, 6], move_array[i, 7])
        saturn.set_data(move_array[i, 8], move_array[i, 9])
        yup.set_data(move_array[i, 10], move_array[i, 11])
        merc.set_data(move_array[i, 12], move_array[i, 13])
        earth.set_data(move_array[i, 14], move_array[i, 15])
        uran.set_data(move_array[i, 16], move_array[i, 17])
        neptun.set_data(move_array[i, 18], move_array[i, 19])
        mars2.set_data(move_array[i, 20], move_array[i, 21])
        ven2.set_data(move_array[i, 22], move_array[i, 23])
        saturn2.set_data(move_array[i, 24], move_array[i, 25])
        yup2.set_data(move_array[i, 26], move_array[i, 27])
        merc2.set_data(move_array[i, 28], move_array[i, 29])
        earth2.set_data(move_array[i, 30], move_array[i, 31])
        uran2.set_data(move_array[i, 32], move_array[i, 33])
        neptun2.set_data(move_array[i, 34], move_array[i, 35])
    
    label = Tk.Label(root,text="Столкновение!").grid(column=0, row=0)
    
    canvas = FigureCanvasTkAgg(fig, master=root)
    canvas.get_tk_widget().grid(column=0,row=1)
    
    ani = animation.FuncAnimation(fig, update, frames=100, interval=100)
    
    ax.set_xlim(-2*10**13, 2*10**13)
    ax.set_ylim(-1*10**13, 1*10**13)
    
    Tk.mainloop()

def clicked5():  
    root = Tk.Tk()
    global entry_6
    global entry_7
    entry_6 = Tk.Entry(root)
    entry_6.grid(column=1, row=0)
    
    entry_7 = Tk.Entry(root)
    entry_7.grid(column=2, row=0)
    
    label6 = Tk.Label(root, text="масса")
    label6.grid(column=0, row=0)
    
    label6 = Tk.Label(root, text="(число из первой строки умножаем на 10 в степени из второй)")
    label6.grid(column=3, row=0)
    
    button = Tk.Button(root, text='показать результат', command=func5)
    button.grid(column=0, row=3)
def clicked6():  
    root = Tk.Tk()
    global entry_1
    global entry_2
    global entry_3
    global entry_4
    global entry_5
    global entry_10
    entry_1 = Tk.Entry(root)
    entry_2 = Tk.Entry(root)
    entry_3 = Tk.Entry(root)
    entry_4 = Tk.Entry(root)
    entry_5 = Tk.Entry(root)
    entry_10 = Tk.Entry(root)
    entry_1.grid(column=1, row=0)
    entry_4.grid(column=2, row=0)
    entry_2.grid(column=1, row=1)
    entry_3.grid(column=1, row=2)
    entry_5.grid(column=2, row=2)
    entry_10.grid(column=1, row=3)
    label1 = Tk.Label(root, text="масса")
    label1.grid(column=0, row=0)
    
    label2 = Tk.Label(root, text="скорость")
    label2.grid(column=0, row=1)
    
    label2 = Tk.Label(root, text="расстояние до Солнца")
    label2.grid(column=0, row=2)
    
    label3 = Tk.Label(root, text="время")
    label3.grid(column=0, row=3)
    
    button = Tk.Button(root, text='показать результат', command=func)
    button.grid(column=0, row=4)
    
    label7 = Tk.Label(root, text="(число из первой строки умножаем на 10 в степени из второй)")
    label7.grid(column=3, row=0)
    
    label8 = Tk.Label(root, text="(число из первой строки умножаем на 10 в степени из второй)")
    label8.grid(column=3, row=2)
def func():
    
    m_star1 = float(entry_1.get())
    n1=float(entry_4.get())
    m_star=m_star1*10**n1
    
    v_x_star0 = float(entry_2.get())
    
    x_star01 = float(entry_3.get())
    
    global years
    years= float(entry_10.get())
    
    n2=float(entry_5.get())
    x_star0= x_star01*10**n2
    sec_y=365*24*60*60
    sec_d=24*60*60
    
    # определяем переменную величину
    t=np.arange(0,sec_y*years, sec_d*5)
    
    fig = plt.Figure()
    root = Tk.Tk()
    #Определяем начальные значения и параметры, входящие в систему диф. уравнений     
    m_sun=1.98847*10**30

    G=6.67*10**(-11)
    
    
    x_sun0=0
    v_x_sun0=0
    y_sun0=0
    v_y_sun0=0

    y_star0=0
    v_y_star0=0
    
    x0_mars= 0
    v_x0_mars=24100
    y0_mars=-228*10**9
    v_y0_mars=0
    
    x0_ven=-108*10**9
    v_x0_ven=0
    y0_ven=0
    v_y0_ven=-35000
    
    x0_saturn=0
    v_x0_saturn=-9690
    y0_saturn=1430*10**9
    v_y0_saturn=0
    
    x0_yup=0
    v_x0_yup=-13070
    y0_yup=778.57*10**9
    v_y0_yup=0
    
    x0_merc=58*10**9
    v_x0_merc=0
    y0_merc=0
    v_y0_merc=48000
    
    x0_earth=-150*10**9
    v_x0_earth=0 
    y0_earth=0
    v_y0_earth=-30000
    
    
    x0_uran=0
    v_x0_uran=-7000
    y0_uran=2875*10**9
    v_y0_uran=0
    
    x0_neptun=0 
    v_x0_neptun=-5000 
    y0_neptun=4497*10**9 
    v_y0_neptun=0
    
    
    
    s0= (x_sun0, v_x_sun0, y_sun0,v_y_sun0,
         x_star0, v_x_star0, y_star0, v_y_star0,
         x0_mars,v_x0_mars,y0_mars, v_y0_mars, 
        x0_ven,v_x0_ven, y0_ven,v_y0_ven,
        x0_saturn, v_x0_saturn,y0_saturn,v_y0_saturn,
        x0_yup, v_x0_yup, y0_yup, v_y0_yup,
        x0_merc, v_x0_merc, y0_merc, v_y0_merc,
        x0_earth, v_x0_earth, y0_earth, v_y0_earth,
        x0_uran, v_x0_uran, y0_uran, v_y0_uran,
        x0_neptun, v_x0_neptun, y0_neptun, v_y0_neptun)  
    
    #определяем функцию для системы дифферинциальных уравнений
    def grav_func(s,t):
         """
         Функция, определяющая динамику тел Солнечной системы
         под влиянием Солнца и второй звезды, находящейся в Солнечной системе. 
         Влияние планет друг на друга не учитывается, 
         так как является незначительным.
         """
         (x_sun, v_x_sun, y_sun, v_y_sun,
          x_star, v_x_star, y_star, v_y_star,
          x_mars, v_x_mars, y_mars, v_y_mars,
          x_ven, v_x_ven, y_ven, v_y_ven,
          x_saturn, v_x_saturn, y_saturn, v_y_saturn,
          x_yup, v_x_yup, y_yup, v_y_yup,
          x_merc, v_x_merc, y_merc, v_y_merc,
          x_earth, v_x_earth, y_earth, v_y_earth,
          x_uran, v_x_uran, y_uran, v_y_uran,
          x_neptun, v_x_neptun, y_neptun, v_y_neptun) = s
          
         dxdt_star = v_x_star
         dv_xdt_star= -G*m_sun* (x_star-x_sun)/((x_star-x_sun)**2 + (y_star-y_sun)**2)**1.5
         dydt_star= v_y_star
         dv_ydt_star=-G*m_sun* (y_star-y_sun)/((x_star-x_sun)**2 + (y_star-y_sun)**2)**1.5 
         
         dxdt_sun= v_x_sun
         dv_xdt_sun= -G*m_star* (x_sun-x_star)/((x_sun-x_star)**2 + (y_sun-y_star)**2)**1.5
         dydt_sun= v_y_sun
         dv_ydt_sun= -G*m_star* (y_sun-y_star)/((x_sun-x_star)**2 + (y_sun-y_star)**2)**1.5
         
    
         dxdt_mars= v_x_mars
         dv_xdt_mars= (-G*m_star* (x_mars-x_star)/((x_mars-x_star)**2 + (y_mars-y_star)**2)**1.5
                       -G*m_sun* (x_mars-x_sun)/((x_mars-x_sun)**2 + (y_mars-y_sun)**2)**1.5)
         dydt_mars= v_y_mars
         dv_ydt_mars= (-G*m_star* (y_mars-y_star)/((x_mars-x_star)**2 + (y_mars-y_star)**2)**1.5
                       -G*m_sun* (y_mars-y_sun)/((x_mars-x_sun)**2 + (y_mars-y_sun)**2)**1.5)
         
         
         dxdt_ven= v_x_ven
         dv_xdt_ven= (-G*m_star* (x_ven-x_star)/((x_ven-x_star)**2 + (y_ven-y_star)**2)**1.5
                      -G*m_sun* (x_ven-x_sun)/((x_ven-x_sun)**2 + (y_ven-y_sun)**2)**1.5)
         dydt_ven= v_y_ven
         dv_ydt_ven= (-G*m_star* (y_ven-y_star)/((x_ven-x_star)**2 + (y_ven-y_star)**2)**1.5
                      -G*m_sun* (y_ven-y_sun)/((x_ven-x_sun)**2 + (y_ven-y_sun)**2)**1.5)
         
         
         dxdt_saturn= v_x_saturn
         dv_xdt_saturn= (-G*m_star* (x_saturn-x_star)/((x_saturn-x_star)**2 + (y_saturn-y_star)**2)**1.5
                         -G*m_sun* (x_saturn-x_sun)/((x_saturn-x_sun)**2 + (y_saturn-y_sun)**2)**1.5)
         dydt_saturn= v_y_saturn
         dv_ydt_saturn= (-G*m_star* (y_saturn-y_star)/((x_saturn-x_star)**2 + (y_saturn-y_star)**2)**1.5
                         -G*m_sun* (y_saturn-y_sun)/((x_saturn-x_sun)**2 + (y_saturn-y_sun)**2)**1.5)
         
         dxdt_yup= v_x_yup
         dv_xdt_yup= (-G*m_star* (x_yup-x_star)/((x_yup-x_star)**2 + (y_yup-y_star)**2)**1.5
                      -G*m_sun* (x_yup-x_sun)/((x_yup-x_sun)**2 + (y_yup-y_sun)**2)**1.5)
         dydt_yup= v_y_yup
         dv_ydt_yup= (-G*m_star* (y_yup-y_star)/((x_yup-x_star)**2 + (y_yup-y_star)**2)**1.5
                      -G*m_sun* (y_yup-y_sun)/((x_yup-x_sun)**2 + (y_yup-y_sun)**2)**1.5)
         
         dxdt_merc= v_x_merc
         dv_xdt_merc= (-G*m_star* (x_merc-x_star)/((x_merc-x_star)**2 + (y_merc-y_star)**2)**1.5
                       -G*m_sun* (x_merc-x_sun)/((x_merc-x_sun)**2 + (y_merc-y_sun)**2)**1.5)
         dydt_merc= v_y_merc
         dv_ydt_merc= (-G*m_star* (y_merc-y_star)/((x_merc-x_star)**2 + (y_merc-y_star)**2)**1.5
                       -G*m_sun* (y_merc-y_sun)/((x_merc-x_sun)**2 + (y_merc-y_sun)**2)**1.5)
             
         dxdt_earth= v_x_earth
         dv_xdt_earth= (-G*m_star* (x_earth-x_star)/((x_earth-x_star)**2 + (y_earth-y_star)**2)**1.5
                        -G*m_sun* (x_earth-x_sun)/((x_earth-x_sun)**2 + (y_earth-y_sun)**2)**1.5)
         dydt_earth= v_y_earth
         dv_ydt_earth= (-G*m_star* (y_earth-y_star)/((x_earth-x_star)**2 + (y_earth-y_star)**2)**1.5
                        -G*m_sun* (y_earth-y_sun)/((x_earth-x_sun)**2 + (y_earth-y_sun)**2)**1.5)
         
         
         dxdt_uran= v_x_uran
         dv_xdt_uran= (-G*m_star* (x_uran-x_star)/((x_uran-x_star)**2 + (y_uran-y_star)**2)**1.5
                        -G*m_sun* (x_uran-x_sun)/((x_uran-x_sun)**2 + (y_uran-y_sun)**2)**1.5)
         dydt_uran= v_y_uran
         dv_ydt_uran= (-G*m_star* (y_uran-y_star)/((x_uran-x_star)**2 + (y_uran-y_star)**2)**1.5
                        -G*m_sun* (y_uran-y_sun)/((x_uran-x_sun)**2 + (y_uran-y_sun)**2)**1.5)
    
              
         dxdt_neptun= v_x_neptun
         dv_xdt_neptun= (-G*m_star* (x_neptun-x_star)/((x_neptun-x_star)**2 + (y_neptun-y_star)**2)**1.5
                        -G*m_sun* (x_neptun-x_sun)/((x_neptun-x_sun)**2 + (y_neptun-y_sun)**2)**1.5)
         dydt_neptun= v_y_neptun
         dv_ydt_neptun= (-G*m_star* (y_neptun-y_star)/((x_neptun-x_star)**2 + (y_neptun-y_star)**2)**1.5
                        -G*m_sun* (y_neptun-y_sun)/((x_neptun-x_sun)**2 + (y_neptun-y_sun)**2)**1.5)
         
         return(dxdt_sun, dv_xdt_sun, dydt_sun, dv_ydt_sun,
                dxdt_star,dv_xdt_star, dydt_star, dv_ydt_star,
                dxdt_mars, dv_xdt_mars, dydt_mars, dv_ydt_mars,
                dxdt_ven, dv_xdt_ven, dydt_ven, dv_ydt_ven,
                dxdt_saturn,dv_xdt_saturn, dydt_saturn, dv_ydt_saturn,
                dxdt_yup,dv_xdt_yup,dydt_yup, dv_ydt_yup,
                dxdt_merc, dv_xdt_merc, dydt_merc, dv_ydt_merc,
                dxdt_earth, dv_xdt_earth, dydt_earth, dv_ydt_earth,
                dxdt_uran, dv_xdt_uran, dydt_uran, dv_ydt_uran,
                dxdt_neptun, dv_xdt_neptun, dydt_neptun, dv_ydt_neptun)
    
    
    #решаем систему диф.уравнений  
    sol=odeint(grav_func, s0, t)
    
    #строим решение в виде графика и анимируем
    ax = fig.add_subplot()
    
    sun, = ax.plot([], [], '*', color='y')
    star, = ax.plot([], [], '*', color='r')
    mars, = ax.plot([],[], 'o', color='orangered')
    ven, = ax.plot([], [],'o', color= 'maroon')
    saturn, = ax.plot([], [], 'o', color='wheat')
    yup, = ax.plot([],[], 'o', color='burlywood')
    merc, = ax.plot([],[], 'o', color='goldenrod')
    earth, = ax.plot([],[], 'o', color='lightseagreen')
    uran, = ax.plot([],[], 'o', color='deepskyblue')
    neptun, = ax.plot([],[], 'o', color='steelblue')
    
    def update(i): #Функция подстановки координат в анимируемый объект
        sun.set_data(sol[i, 0], sol[i, 2])
        star.set_data(sol[i, 4], sol[i, 6])
        mars.set_data(sol[i, 8], sol[i, 10])
        ven.set_data(sol[i, 12], sol[i, 14])
        saturn.set_data(sol[i, 16], sol[i, 18])
        yup.set_data(sol[i, 20], sol[i, 22])
        merc.set_data(sol[i, 24], sol[i, 26])
        earth.set_data(sol[i, 28], sol[i, 30])
        uran.set_data(sol[i, 32], sol[i, 34])
        neptun.set_data(sol[i, 36], sol[i, 38])
    
    label = Tk.Label(root,text="Ещё одна звезда в Солнечной системе!").grid(column=0, row=0)
    
    canvas = FigureCanvasTkAgg(fig, master=root)
    canvas.get_tk_widget().grid(column=0,row=1)
    
    ani = animation.FuncAnimation(fig, update, frames=100, interval=100)
    
    ax.set_xlim(y0_neptun, -y0_neptun)
    ax.set_ylim(y0_neptun, -y0_neptun)
    
    Tk.mainloop()
    
def func2():    
    m_sun = 1.98847 * 10**30
    G = 6.67 * 10**(-11)
    sec_y = 365 * 24 * 60 * 60
    sec_d = 24 * 60 * 60
    years = 10
    t=np.arange(0, years*sec_y, sec_d*5)
    
    fig = plt.Figure()
    root = Tk.Tk()
    
    x0_mars= 0
    v_x0_mars=24100
    y0_mars=-228*10**9
    v_y0_mars=0
    
    x0_ven=-108*10**9
    v_x0_ven=0
    y0_ven=0
    v_y0_ven=-35000
    
    x0_saturn=0
    v_x0_saturn=-9690
    y0_saturn=1430*10**9
    v_y0_saturn=0
    
    x0_yup=0
    v_x0_yup=-13070
    y0_yup=778.57*10**9
    v_y0_yup=0
    
    x0_merc=58*10**9
    v_x0_merc=0
    y0_merc=0
    v_y0_merc=48000
    
    x0_earth=-150*10**9
    v_x0_earth=0
    y0_earth=0
    v_y0_earth=-30000
    
    x0_uran=0
    v_x0_uran=-7000
    y0_uran=2875*10**9
    v_y0_uran=0
    
    x0_neptun=0
    v_x0_neptun=-5000
    y0_neptun=4497*10**9
    v_y0_neptun=0
    
    z0=(x0_mars,v_x0_mars,y0_mars, v_y0_mars,
        x0_ven,v_x0_ven, y0_ven,v_y0_ven,
        x0_saturn, v_x0_saturn,y0_saturn,v_y0_saturn,
        x0_yup, v_x0_yup, y0_yup, v_y0_yup,
        x0_merc, v_x0_merc, y0_merc, v_y0_merc,
        x0_earth, v_x0_earth, y0_earth, v_y0_earth,
        x0_uran, v_x0_uran, y0_uran, v_y0_uran,
        x0_neptun, v_x0_neptun, y0_neptun, v_y0_neptun )
    
    def grav_func(z,t):
         (x_mars, v_x_mars, y_mars, v_y_mars,
          x_ven, v_x_ven, y_ven, v_y_ven,
          x_saturn, v_x_saturn, y_saturn, v_y_saturn,
          x_yup, v_x_yup, y_yup, v_y_yup,
          x_merc, v_x_merc, y_merc, v_y_merc,
          x_earth, v_x_earth, y_earth, v_y_earth,
          x_uran, v_x_uran, y_uran, v_y_uran,
          x_neptun, v_x_neptun, y_neptun, v_y_neptun) = z
    
         dxdt_mars = v_x_mars
         dv_xdt_mars = -G*m_sun* x_mars/(x_mars**2+y_mars**2)**1.5
         dydt_mars = v_y_mars
         dv_ydt_mars = -G*m_sun* y_mars/(x_mars**2+y_mars**2)**1.5
    
         dxdt_ven = v_x_ven
         dv_xdt_ven = -G*m_sun* x_ven/(x_ven**2+y_ven**2)**1.5
         dydt_ven = v_y_ven
         dv_ydt_ven = -G*m_sun* y_ven/(x_ven**2+y_ven**2)**1.5
    
         dxdt_saturn = v_x_saturn
         dv_xdt_saturn = -G*m_sun* x_saturn/(x_saturn**2+y_saturn**2)**1.5
         dydt_saturn = v_y_saturn
         dv_ydt_saturn = -G*m_sun* y_saturn/(x_saturn**2+y_saturn**2)**1.5
    
         dxdt_yup = v_x_yup
         dv_xdt_yup = -G*m_sun* x_yup/(x_yup**2+y_yup**2)**1.5
         dydt_yup = v_y_yup
         dv_ydt_yup = -G*m_sun* y_yup/(x_yup**2+y_yup**2)**1.5
    
         dxdt_merc = v_x_merc
         dv_xdt_merc = -G*m_sun* x_merc/(x_merc**2+y_merc**2)**1.5
         dydt_merc = v_y_merc
         dv_ydt_merc = -G*m_sun* y_merc/(x_merc**2+y_merc**2)**1.5
    
         dxdt_earth = v_x_earth
         dv_xdt_earth = -G*m_sun* x_earth/(x_earth**2+y_earth**2)**1.5
         dydt_earth = v_y_earth
         dv_ydt_earth = -G*m_sun* y_earth/(x_earth**2+y_earth**2)**1.5
    
         dxdt_uran = v_x_uran
         dv_xdt_uran = -G*m_sun* x_uran/(x_uran**2+y_uran**2)**1.5
         dydt_uran = v_y_uran
         dv_ydt_uran = -G*m_sun* y_uran/(x_uran**2+y_uran**2)**1.5
    
         dxdt_neptun = v_x_neptun
         dv_xdt_neptun = -G*m_sun* x_neptun/(x_neptun**2+y_neptun**2)**1.5
         dydt_neptun = v_y_neptun
         dv_ydt_neptun = -G*m_sun* y_neptun/(x_neptun**2+y_neptun**2)**1.5
    
         return(dxdt_mars, dv_xdt_mars, dydt_mars, dv_ydt_mars,
                dxdt_ven, dv_xdt_ven, dydt_ven, dv_ydt_ven,
                dxdt_saturn, dv_xdt_saturn, dydt_saturn, dv_ydt_saturn,
                dxdt_yup, dv_xdt_yup,dydt_yup, dv_ydt_yup,
                dxdt_merc, dv_xdt_merc, dydt_merc, dv_ydt_merc,
                dxdt_earth, dv_xdt_earth, dydt_earth, dv_ydt_earth,
                dxdt_uran, dv_xdt_uran, dydt_uran, dv_ydt_uran,
                dxdt_neptun, dv_xdt_neptun,dydt_neptun, dv_ydt_neptun )
    
    sol = odeint(grav_func, z0, t)
    
    ax = fig.add_subplot()
    
    sun, = ax.plot([0], [0], 'o', color='y')
    mars, = ax.plot([],[], 'o', color='orangered')
    ven, = ax.plot([], [],'o', color= 'maroon')
    saturn, = ax.plot([], [], 'o', color='wheat')
    yup, = ax.plot([],[], 'o', color='burlywood')
    merc, = ax.plot([],[], 'o', color='goldenrod')
    earth, = ax.plot([],[], 'o', color='lightseagreen')
    uran, = ax.plot([],[], 'o', color='deepskyblue')
    neptun, = ax.plot([],[], 'o', color='steelblue')
    
    def update(i): #Функция подстановки координат в анимируемый объект
        mars.set_data(sol[i, 0], sol[i, 2])
        ven.set_data(sol[i, 4], sol[i, 6])
        saturn.set_data(sol[i, 8], sol[i, 10])
        yup.set_data(sol[i, 12], sol[i, 14])
        merc.set_data(sol[i, 16], sol[i, 18])
        earth.set_data(sol[i, 20], sol[i, 22])
        uran.set_data(sol[i, 24], sol[i, 26])
        neptun.set_data(sol[i, 28], sol[i, 30])
    
    label = Tk.Label(root,text="Солнечная система").grid(column=0, row=0)
    
    canvas = FigureCanvasTkAgg(fig, master=root)
    canvas.get_tk_widget().grid(column=0,row=1)
    
    ani = animation.FuncAnimation(fig, update, frames=100, interval=100)
    
    ax.set_xlim(y0_neptun, -y0_neptun)
    ax.set_ylim(y0_neptun, -y0_neptun)
    
    Tk.mainloop()
def func3():
    
    sec_y=365*24*60*60
    sec_d=24*60*60
    years=5
    t=np.arange(0,years*sec_y,sec_d)
    
    G=6.67*10**(-11)
    sun_mass=1.9*10**30
    
    fig = plt.Figure()
    root = Tk.Tk()
    
    x0_mars= 0
    v_x0_mars=24100
    y0_mars=-228*10**9
    v_y0_mars=0
    
    x0_ven=-108*10**9
    v_x0_ven=0
    y0_ven=0
    v_y0_ven=-35000
    
    
    x0_merc=58*10**9
    v_x0_merc=0
    y0_merc=0
    v_y0_merc=48000
    
    x0_earth=-150*10**9
    v_x0_earth=0 
    y0_earth=0
    v_y0_earth=-30000
    
    
    z0=(x0_mars,v_x0_mars,y0_mars, v_y0_mars, 
        x0_ven,v_x0_ven, y0_ven,v_y0_ven,
        x0_merc, v_x0_merc, y0_merc, v_y0_merc,
        x0_earth, v_x0_earth, y0_earth, v_y0_earth)
    
    def grav_func(z,t):
         (x_mars, v_x_mars, y_mars, v_y_mars,
          x_ven, v_x_ven, y_ven, v_y_ven,
          x_merc, v_x_merc, y_merc, v_y_merc,
          x_earth, v_x_earth, y_earth, v_y_earth)= z
         dxdt_mars= v_x_mars
         dv_xdt_mars= -G*sun_mass* x_mars/(x_mars**2+y_mars**2)**1.5
         dydt_mars= v_y_mars
         dv_ydt_mars= -G*sun_mass* y_mars/(x_mars**2+y_mars**2)**1.5
         
         dxdt_ven= v_x_ven
         dv_xdt_ven= -G*sun_mass* x_ven/(x_ven**2+y_ven**2)**1.5
         dydt_ven= v_y_ven
         dv_ydt_ven= -G*sun_mass* y_ven/(x_ven**2+y_ven**2)**1.5
         
         dxdt_merc= v_x_merc
         dv_xdt_merc= -G*sun_mass* x_merc/(x_merc**2+y_merc**2)**1.5
         dydt_merc= v_y_merc
         dv_ydt_merc= -G*sun_mass* y_merc/(x_merc**2+y_merc**2)**1.5
             
         dxdt_earth= v_x_earth
         dv_xdt_earth= -G*sun_mass* x_earth/(x_earth**2+y_earth**2)**1.5
         dydt_earth= v_y_earth
         dv_ydt_earth= -G*sun_mass* y_earth/(x_earth**2+y_earth**2)**1.5  
         
         return(dxdt_mars, dv_xdt_mars, dydt_mars, dv_ydt_mars, 
                dxdt_ven, dv_xdt_ven, dydt_ven, dv_ydt_ven,
                 dxdt_merc, dv_xdt_merc, dydt_merc, dv_ydt_merc,
                 dxdt_earth, dv_xdt_earth, dydt_earth, dv_ydt_earth )
    
    
    sol=odeint(grav_func, z0, t)
    
    ax = fig.add_subplot()
    
    sun, = ax.plot([0], [0], 'o', color='y')
    mars, = ax.plot([],[], 'o', color='orangered')
    ven, = ax.plot([], [],'o', color= 'maroon')
    merc, = ax.plot([],[], 'o', color='goldenrod')
    earth, = ax.plot([],[], 'o', color='lightseagreen')
    
    
    def update(i): #Функция подстановки координат в анимируемый объект
        mars.set_data(sol[i, 0], sol[i, 2])
        ven.set_data(sol[i, 4], sol[i, 6])
        merc.set_data(sol[i, 8], sol[i, 10])
        earth.set_data(sol[i, 12], sol[i, 14])
    
    label = Tk.Label(root,text="Планеты Земной группы").grid(column=0, row=0)
    
    canvas = FigureCanvasTkAgg(fig, master=root)
    canvas.get_tk_widget().grid(column=0,row=1)
    
    ani = animation.FuncAnimation(fig, update, frames=150, interval=100)
    
    n=10**5
    ax.set_xlim(y0_mars+n, -y0_mars+n)
    ax.set_ylim(y0_mars+n, -y0_mars+n)
    
    Tk.mainloop()

def func4():
    #временные интервалы
    sec_y=365*24*60*60
    sec_d=24*60*60
    years=30
    # определяем переменную величину
    t=np.arange(0,years*sec_y,sec_d*50)
    
    
    G=6.67*10**(-11)
    sun_mass=1.9*10**30
    
    
    fig = plt.Figure()
    root = Tk.Tk()
    
    #Определяем начальные значения и параметры, входящие в систему диф. уравнений
    x0_saturn=0
    v_x0_saturn=-9690
    y0_saturn=1430*10**9
    v_y0_saturn=0
    
    x0_yup=0
    v_x0_yup=-13070
    y0_yup=778.57*10**9
    v_y0_yup=0
    
    x0_uran=0
    v_x0_uran=-7000
    y0_uran=2875*10**9
    v_y0_uran=0
    
    x0_neptun=0
    v_x0_neptun=-5000
    y0_neptun=4497*10**9
    v_y0_neptun=0
    
    
    z0=(x0_saturn, v_x0_saturn,y0_saturn,v_y0_saturn,
        x0_yup, v_x0_yup, y0_yup, v_y0_yup,
        x0_uran, v_x0_uran, y0_uran, v_y0_uran,
        x0_neptun, v_x0_neptun, y0_neptun, v_y0_neptun )
    #определяем функцию для системы дифферинциальных уравнений
    def grav_func(z,t):
         """
         Функция, определяющая динамику планет-гигантов Солнечной системы,
         начиная с Юпитера и заканчивая Нептуном,
         под влиянием Солнца.
         Влияние планет друг на друга не учитывается, 
         так как является незначительным.
         """
         ( x_saturn, v_x_saturn, y_saturn, v_y_saturn,
          x_yup, v_x_yup, y_yup, v_y_yup,
          x_uran, v_x_uran, y_uran, v_y_uran,
          x_neptun, v_x_neptun, y_neptun, v_y_neptun)= z
         
         dxdt_saturn= v_x_saturn
         dv_xdt_saturn= -G*sun_mass* x_saturn/(x_saturn**2+y_saturn**2)**1.5
         dydt_saturn= v_y_saturn
         dv_ydt_saturn= -G*sun_mass* y_saturn/(x_saturn**2+y_saturn**2)**1.5
         
         dxdt_yup= v_x_yup
         dv_xdt_yup= -G*sun_mass* x_yup/(x_yup**2+y_yup**2)**1.5
         dydt_yup= v_y_yup
         dv_ydt_yup= -G*sun_mass* y_yup/(x_yup**2+y_yup**2)**1.5
         
         dxdt_uran= v_x_uran
         dv_xdt_uran= -G*sun_mass* x_uran/(x_uran**2+y_uran**2)**1.5
         dydt_uran= v_y_uran
         dv_ydt_uran= -G*sun_mass* y_uran/(x_uran**2+y_uran**2)**1.5
         
         dxdt_neptun= v_x_neptun
         dv_xdt_neptun= -G*sun_mass* x_neptun/(x_neptun**2+y_neptun**2)**1.5
         dydt_neptun= v_y_neptun
         dv_ydt_neptun= -G*sun_mass* y_neptun/(x_neptun**2+y_neptun**2)**1.5
    
    
         return(dxdt_saturn,dv_xdt_saturn, dydt_saturn, dv_ydt_saturn,
                dxdt_yup,dv_xdt_yup,dydt_yup, dv_ydt_yup,
                 dxdt_uran, dv_xdt_uran, dydt_uran, dv_ydt_uran,
                 dxdt_neptun, dv_xdt_neptun,dydt_neptun, dv_ydt_neptun )
    
    #решаем систему диф.уравнений 
    sol=odeint(grav_func, z0, t)
    #строим решение в виде графика и анимируем
    
    ax = fig.add_subplot()
    
    sun, = ax.plot([0], [0], 'o', color='y')
    saturn, = ax.plot([],[], 'o', color='wheat')
    yup, = ax.plot([], [],'o', color= 'burlywood')
    uran, = ax.plot([],[], 'o', color='deepskyblue')
    neptun, = ax.plot([],[], 'o', color='steelblue')
    
    
    def update(i): #Функция подстановки координат в анимируемый объект
        saturn.set_data(sol[i, 0], sol[i, 2])
        yup.set_data(sol[i, 4], sol[i, 6])
        uran.set_data(sol[i, 8], sol[i, 10])
        neptun.set_data(sol[i, 12], sol[i, 14])
    
    label = Tk.Label(root,text="Планеты-гиганты").grid(column=0, row=0)
    
    canvas = FigureCanvasTkAgg(fig, master=root)
    canvas.get_tk_widget().grid(column=0,row=1)
    
    ani = animation.FuncAnimation(fig, update, frames=150, interval=100)
    
    n=10**5
    ax.set_xlim(y0_neptun+n, -y0_neptun+n)
    ax.set_ylim(y0_neptun+n, -y0_neptun+n)
    
    Tk.mainloop()       
def func5():
    m_sun2_2=float(entry_6.get())
    n_msun2=float(entry_7.get())
    m_sun2=m_sun2_2*10**n_msun2
    G = 6.67 * 10**(-11)
    sec_y = 365 * 24 * 60 * 60
    sec_d = 24 * 60 * 60
    years = 10
    t=np.arange(0, years*sec_y, sec_d*5)
    
    fig = plt.Figure()
    root = Tk.Tk()
    
    x0_mars= 0
    v_x0_mars=24100
    y0_mars=-228*10**9
    v_y0_mars=0
    
    x0_ven=-108*10**9
    v_x0_ven=0
    y0_ven=0
    v_y0_ven=-35000
    
    x0_saturn=0
    v_x0_saturn=-9690
    y0_saturn=1430*10**9
    v_y0_saturn=0
    
    x0_yup=0
    v_x0_yup=-13070
    y0_yup=778.57*10**9
    v_y0_yup=0
    
    x0_merc=58*10**9
    v_x0_merc=0
    y0_merc=0
    v_y0_merc=48000
    
    x0_earth=-150*10**9
    v_x0_earth=0
    y0_earth=0
    v_y0_earth=-30000
    
    x0_uran=0
    v_x0_uran=-7000
    y0_uran=2875*10**9
    v_y0_uran=0
    
    x0_neptun=0
    v_x0_neptun=-5000
    y0_neptun=4497*10**9
    v_y0_neptun=0
    
    z0=(x0_mars,v_x0_mars,y0_mars, v_y0_mars,
        x0_ven,v_x0_ven, y0_ven,v_y0_ven,
        x0_saturn, v_x0_saturn,y0_saturn,v_y0_saturn,
        x0_yup, v_x0_yup, y0_yup, v_y0_yup,
        x0_merc, v_x0_merc, y0_merc, v_y0_merc,
        x0_earth, v_x0_earth, y0_earth, v_y0_earth,
        x0_uran, v_x0_uran, y0_uran, v_y0_uran,
        x0_neptun, v_x0_neptun, y0_neptun, v_y0_neptun )
    
    def grav_func(z,t):
         (x_mars, v_x_mars, y_mars, v_y_mars,
          x_ven, v_x_ven, y_ven, v_y_ven,
          x_saturn, v_x_saturn, y_saturn, v_y_saturn,
          x_yup, v_x_yup, y_yup, v_y_yup,
          x_merc, v_x_merc, y_merc, v_y_merc,
          x_earth, v_x_earth, y_earth, v_y_earth,
          x_uran, v_x_uran, y_uran, v_y_uran,
          x_neptun, v_x_neptun, y_neptun, v_y_neptun) = z
    
         dxdt_mars = v_x_mars
         dv_xdt_mars = -G*m_sun2* x_mars/(x_mars**2+y_mars**2)**1.5
         dydt_mars = v_y_mars
         dv_ydt_mars = -G*m_sun2* y_mars/(x_mars**2+y_mars**2)**1.5
    
         dxdt_ven = v_x_ven
         dv_xdt_ven = -G*m_sun2* x_ven/(x_ven**2+y_ven**2)**1.5
         dydt_ven = v_y_ven
         dv_ydt_ven = -G*m_sun2* y_ven/(x_ven**2+y_ven**2)**1.5
    
         dxdt_saturn = v_x_saturn
         dv_xdt_saturn = -G*m_sun2* x_saturn/(x_saturn**2+y_saturn**2)**1.5
         dydt_saturn = v_y_saturn
         dv_ydt_saturn = -G*m_sun2* y_saturn/(x_saturn**2+y_saturn**2)**1.5
    
         dxdt_yup = v_x_yup
         dv_xdt_yup = -G*m_sun2* x_yup/(x_yup**2+y_yup**2)**1.5
         dydt_yup = v_y_yup
         dv_ydt_yup = -G*m_sun2* y_yup/(x_yup**2+y_yup**2)**1.5
    
         dxdt_merc = v_x_merc
         dv_xdt_merc = -G*m_sun2* x_merc/(x_merc**2+y_merc**2)**1.5
         dydt_merc = v_y_merc
         dv_ydt_merc = -G*m_sun2* y_merc/(x_merc**2+y_merc**2)**1.5
    
         dxdt_earth = v_x_earth
         dv_xdt_earth = -G*m_sun2* x_earth/(x_earth**2+y_earth**2)**1.5
         dydt_earth = v_y_earth
         dv_ydt_earth = -G*m_sun2* y_earth/(x_earth**2+y_earth**2)**1.5
    
         dxdt_uran = v_x_uran
         dv_xdt_uran = -G*m_sun2* x_uran/(x_uran**2+y_uran**2)**1.5
         dydt_uran = v_y_uran
         dv_ydt_uran = -G*m_sun2* y_uran/(x_uran**2+y_uran**2)**1.5
    
         dxdt_neptun = v_x_neptun
         dv_xdt_neptun = -G*m_sun2* x_neptun/(x_neptun**2+y_neptun**2)**1.5
         dydt_neptun = v_y_neptun
         dv_ydt_neptun = -G*m_sun2* y_neptun/(x_neptun**2+y_neptun**2)**1.5
    
         return(dxdt_mars, dv_xdt_mars, dydt_mars, dv_ydt_mars,
                dxdt_ven, dv_xdt_ven, dydt_ven, dv_ydt_ven,
                dxdt_saturn, dv_xdt_saturn, dydt_saturn, dv_ydt_saturn,
                dxdt_yup, dv_xdt_yup,dydt_yup, dv_ydt_yup,
                dxdt_merc, dv_xdt_merc, dydt_merc, dv_ydt_merc,
                dxdt_earth, dv_xdt_earth, dydt_earth, dv_ydt_earth,
                dxdt_uran, dv_xdt_uran, dydt_uran, dv_ydt_uran,
                dxdt_neptun, dv_xdt_neptun,dydt_neptun, dv_ydt_neptun )

    
    sol = odeint(grav_func, z0, t)
    
    ax = fig.add_subplot()
    
    sun, = ax.plot([0], [0], 'o', color='y')
    mars, = ax.plot([],[], 'o', color='orangered')
    ven, = ax.plot([], [],'o', color= 'maroon')
    saturn, = ax.plot([], [], 'o', color='wheat')
    yup, = ax.plot([],[], 'o', color='burlywood')
    merc, = ax.plot([],[], 'o', color='goldenrod')
    earth, = ax.plot([],[], 'o', color='lightseagreen')
    uran, = ax.plot([],[], 'o', color='deepskyblue')
    neptun, = ax.plot([],[], 'o', color='steelblue')
    
    def update(i): #Функция подстановки координат в анимируемый объект
        mars.set_data(sol[i, 0], sol[i, 2])
        ven.set_data(sol[i, 4], sol[i, 6])
        saturn.set_data(sol[i, 8], sol[i, 10])
        yup.set_data(sol[i, 12], sol[i, 14])
        merc.set_data(sol[i, 16], sol[i, 18])
        earth.set_data(sol[i, 20], sol[i, 22])
        uran.set_data(sol[i, 24], sol[i, 26])
        neptun.set_data(sol[i, 28], sol[i, 30])
    
    label = Tk.Label(root,text="Теперь вместо Солнца другая звезда!").grid(column=0, row=0)
    
    canvas = FigureCanvasTkAgg(fig, master=root)
    canvas.get_tk_widget().grid(column=0,row=1)
    
    ani = animation.FuncAnimation(fig, update, frames=100, interval=100)
    
    ax.set_xlim(y0_neptun, -y0_neptun)
    ax.set_ylim(y0_neptun, -y0_neptun)
    
    Tk.mainloop()
def clicked7():
    windows = Toplevel()
    windows.title('Закон сохранения импульса')
    img = ImageTk.PhotoImage(Image.open("impuls.jpg"))
    panel = Label(windows, image=img)
    panel.pack()
    button = Button(windows, text='открыть окно', command= clicked)
    button.place(column=0, row=0)
infmenu = Tk.Menu(mainmenu, tearoff=0)
infmenu.add_command(label="Сила всемирного тяготения", command=clicked)
infmenu.add_command(label="Закон сохранения импульса", command=clicked7)
infmenu.add_command(label="Что есть в Солнечной системе?", command=clicked2)
infmenu.add_command(label="Солнечная система", command=clicked3)

animmenu = Tk.Menu(mainmenu, tearoff=0)
animmenu.add_command(label="Столкновение Солнечных систем", command=clicked4)
animmenu.add_command(label="Другое Солнце", command=clicked5)
animmenu.add_command(label="Второе Солнце", command=clicked6)


mainmenu.add_cascade(label="Информация", menu=infmenu)
mainmenu.add_cascade(label="Эксперименты", menu=animmenu)

 
window.mainloop() 